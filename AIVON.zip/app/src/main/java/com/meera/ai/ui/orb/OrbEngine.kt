package com.meera.ai.ui.orb

import android.os.SystemClock
import androidx.compose.ui.graphics.Path
import com.meera.ai.Meera
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.sin
import kotlin.math.sqrt

/** Mutable per-orb memory: time, smoothed voice level, rotation and the little buffers some styles need. */
class OrbMemory {
    var t = 0f
    var lvl = 0f
    var rot = 0f
    private var lastNanos = 0L

    val path = Path()
    val path2 = Path()

    // ECG trace
    val ecg = FloatArray(150)
    // Spectrum bars
    val bars = FloatArray(27) { 6f }
    // Sonar ripples: birth time and strength
    val rippleT = FloatArray(12)
    val rippleS = FloatArray(12)
    var rippleN = 0
    var lastEmit = 0f
    // Plasma bolt random source
    val rnd = java.util.Random(11)
    // Hacker rain
    val rainY = FloatArray(31) { (it * 37 % 31).toFloat() }
    val rainSp = FloatArray(31) { 0.18f + (it * 13 % 7) * 0.05f }
    val tmp110 = FloatArray(330)
    val tmp420 = FloatArray(1260)
    var hex = "0x3F2A"
    var frame = 0

    // Fibonacci sphere points (unit sphere), made once
    val sphere110: Array<FloatArray> = fib(110)
    val sphere420: Array<FloatArray> = fib(420)
    val nearPairs: Array<IntArray> by lazy {
        val out = ArrayList<IntArray>()
        for (i in sphere110.indices) for (j in i + 1 until sphere110.size) {
            val dx = sphere110[i][0] - sphere110[j][0]
            val dy = sphere110[i][1] - sphere110[j][1]
            val dz = sphere110[i][2] - sphere110[j][2]
            if (sqrt(dx * dx + dy * dy + dz * dz) < 0.52f) out.add(intArrayOf(i, j))
        }
        out.toTypedArray()
    }

    private fun fib(n: Int): Array<FloatArray> = Array(n) { i ->
        val y = 1f - 2f * (i + 0.5f) / n
        val r = sqrt(1f - y * y)
        val ph = i * 2.39996f
        floatArrayOf(cos(ph) * r, y, sin(ph) * r)
    }

    /** Advances time, rotation and the smoothed voice level by one frame. */
    fun step(nowNanos: Long, state: OrbState, cfg: OrbConfig, simulate: Boolean) {
        val dt = if (lastNanos == 0L) 0.016f else ((nowNanos - lastNanos) / 1_000_000_000f).coerceIn(0f, 0.05f)
        lastNanos = nowNanos
        t += dt
        frame++

        var target: Float
        val real = Meera.aura
        val fresh = !simulate && SystemClock.uptimeMillis() - real.realAt < 150L
        val tts = !simulate && real.ttsSpeaking.value
        val env = (0.5f + 0.5f * sin(7.3f * t) * sin(2.1f * t + 1f) + 0.25f * sin(13.7f * t)).coerceIn(0f, 1f)
        target = when {
            fresh && state == OrbState.SPEAK -> (real.realLevel * cfg.gain).coerceIn(0f, 1.2f)
            state == OrbState.SPEAK || tts -> env * cfg.gain * 0.75f
            state == OrbState.LISTEN -> 0.16f + 0.08f * sin(2.2f * t)
            state == OrbState.THINK -> 0.1f + 0.03f * sin(3f * t)
            else -> 0.05f + 0.03f * sin(1.2f * t)
        }
        lvl += (target - lvl) * 0.17f

        val sp = when (state) {
            OrbState.IDLE -> 0.25f
            OrbState.LISTEN -> 0.4f
            OrbState.THINK -> 1.6f
            OrbState.SPEAK -> 0.6f + lvl * 1.2f
        }
        rot += dt * sp * cfg.speed
    }
}

internal fun hash01(n: Float): Float {
    val v = abs(sin(n * 12.9898f) * 43758.547f)
    return v - kotlin.math.floor(v)
}
