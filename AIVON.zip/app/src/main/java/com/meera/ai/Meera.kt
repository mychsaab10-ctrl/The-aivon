package com.meera.ai

import android.app.Application
import android.widget.Toast
import com.meera.ai.ai.Answer
import com.meera.ai.ai.ChatMsg
import com.meera.ai.ai.GeminiClient
import com.meera.ai.ai.GeminiException
import com.meera.ai.ai.Mood
import com.meera.ai.ai.Persona
import com.meera.ai.automation.Actions
import com.meera.ai.automation.Locator
import com.meera.ai.automation.Messaging
import com.meera.ai.automation.ScreenControl
import com.meera.ai.data.AppSettings
import com.meera.ai.data.MemoryRepo
import com.meera.ai.aura.AuraController
import com.meera.ai.data.SecureKeyStore
import com.meera.ai.eyes.EyesCmd
import com.meera.ai.eyes.EyesCommands
import com.meera.ai.eyes.EyesController
import com.meera.ai.ui.ChatSession
import com.meera.ai.voice.CallController
import com.meera.ai.voice.TtsEngine
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableStateFlow
import org.json.JSONObject

/**
 * Result of a tool call. When [ask] is true the action is NOT done yet: Meera must first ask the user
 * (by voice or in chat) and the user answers yes/no ("haan"/"nahi" also work). No popup buttons are involved.
 */
data class ToolOut(val text: String, val ask: Boolean = false, val image: com.meera.ai.ai.Attach? = null) {
    /** What the Gemini Live model receives as the tool result. */
    fun forLive(): String =
        if (ask) {
            "WAITING_FOR_USER_CONFIRMATION. Nothing has been done yet. Ask the user this question in their language, in your own words, then wait: \"$text\" " +
                "When the user answers, call confirm_pending with accepted=true (they said yes) or accepted=false (they said no). Never assume the answer."
        } else text
}

/** A yes/no question that Meera asked the user. [action] executes only after a clear "yes" and returns the result text. */
class Awaiting(val prompt: String, val expiresAt: Long, val action: () -> String)

/** Tiny service locator (keeps the project easy to read for beginners). */
object Meera {
    lateinit var app: Application; private set
    lateinit var keys: SecureKeyStore; private set
    lateinit var settings: AppSettings; private set
    lateinit var gemini: GeminiClient; private set
    lateinit var memory: MemoryRepo; private set
    lateinit var chat: ChatSession; private set
    lateinit var coding: ChatSession; private set
    lateinit var call: CallController; private set
    lateinit var eyes: EyesController; private set
    lateinit var aura: AuraController; private set

    val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)

    /** In-app consent switch for screen control (resets on every app start). */
    val accessGate = MutableStateFlow(false)

    /** Log shown on the Phone Automation screen. */
    val log = MutableStateFlow("")

    /** Mood for Home/Chat: normal | happy | excited | sad | loving | thinking. */
    val mood = MutableStateFlow("normal")

    /** The user's latest sentence (typed or transcribed). Used to verify spoken confirmations. */
    @Volatile var lastUserText: String = ""

    @Volatile var awaiting: Awaiting? = null

    /** Set by MainActivity so contacts permission can be requested the first time a name is used. */
    @Volatile var requestContacts: (() -> Unit)? = null

    /** Set by MainActivity so the CAMERA permission can be requested the first time the user says "open your eyes". */
    @Volatile var requestCamera: (() -> Unit)? = null

    /** Set by MainActivity so the LOCATION permission can be requested the first time the user asks "where am I?". */
    @Volatile var requestLocation: (() -> Unit)? = null

    val tts: TtsEngine by lazy { TtsEngine(app) }

    fun init(a: Application) {
        app = a
        keys = SecureKeyStore(a)
        settings = AppSettings(a)
        gemini = GeminiClient(keys)
        memory = MemoryRepo(a, scope)
        chat = ChatSession("chat")
        coding = ChatSession("coding")
        call = CallController(a, scope)
        eyes = EyesController(a, scope)
        aura = AuraController(a, scope)
        aura.start()
        // background tasks: history from the phone, and the floating window (through the accessibility service)
        try {
            com.meera.ai.tasks.TaskManager.load()
            com.meera.ai.automation.TermuxHistory.load()
            com.meera.ai.tasks.TaskWindow.start(scope)
            com.meera.ai.automation.RemoteStore.load()
            com.meera.ai.automation.RemoteControl.syncStatusNotification()
        } catch (e: Exception) { }
        // reminders: channel, database, and every alarm scheduled again (alarms do not survive a reboot)
        try {
            com.meera.ai.reminders.ReminderStore.ensure(a)
            com.meera.ai.reminders.ReminderNotifier.ensureChannel(a)
            com.meera.ai.reminders.ReminderScheduler.rescheduleAll(a, reportMissed = false)
        } catch (e: Exception) { }
    }

    fun toast(msg: String) = Toast.makeText(app, msg, Toast.LENGTH_LONG).show()

    fun setMood(m: String) { mood.value = m }

    // ───────────── conversational confirmation (replaces popups) ─────────────

    /** Remember what to do after the user says yes, and return the question to ask. */
    fun confirmThen(prompt: String, run: () -> String): ToolOut {
        awaiting = Awaiting(prompt, System.currentTimeMillis() + 120_000, run)
        return ToolOut(prompt, ask = true)
    }

    /**
     * Chat and fallback-voice call this with every user sentence BEFORE sending it to Gemini.
     * Returns the result text if the sentence answered a pending question, otherwise null.
     */
    fun interceptAnswer(text: String): String? {
        val w = awaiting ?: return null
        if (System.currentTimeMillis() > w.expiresAt) { awaiting = null; return null }
        return when (Answer.parse(text)) {
            Answer.YES -> { awaiting = null; w.action() }
            Answer.NO -> { awaiting = null; "Okay, cancelled. I did nothing." }
            Answer.UNSURE -> { awaiting = null; null }
        }
    }

    private fun confirmPending(args: JSONObject): ToolOut {
        val w = awaiting ?: return ToolOut("Nothing is waiting for confirmation.")
        if (System.currentTimeMillis() > w.expiresAt) { awaiting = null; return ToolOut("That question expired. Ask again if still needed.") }
        val accepted = args.optBoolean("accepted", false)
        val said = Answer.parse(lastUserText)
        if (accepted && said != Answer.YES) {
            return ToolOut("The user has NOT clearly said yes. Do nothing. Ask again and wait for a clear 'yes' (or 'haan').")
        }
        awaiting = null
        return if (!accepted || said == Answer.NO) ToolOut("Cancelled. Nothing was done.") else ToolOut(w.action())
    }

    // ───────────── tools coming from Gemini ─────────────

    /** Every tool call goes through here: background-task tracking first, then the real dispatch. */
    suspend fun handleCall(name: String, args: JSONObject): ToolOut =
        com.meera.ai.tasks.TaskManager.track(name, args) { dispatch(name, args) }

    private suspend fun dispatch(name: String, args: JSONObject): ToolOut = when (name) {
        "remember" -> remember(args)
        "forget" -> forget(args)
        "get_location" -> Locator.tool()
        "phone_action" -> phone(args)
        "send_message" -> Messaging.request(args)
        "confirm_pending" -> confirmPending(args)
        "screen_action" -> ScreenControl.run(args).also { log.value = it.text }
        "open_eyes" -> eyesTool(EyesCmd.OPEN)
        "close_eyes" -> eyesTool(EyesCmd.CLOSE)
        "set_reply_style" -> setReplyStyle(args)
        "end_call" -> endCallTool()
        "hangup_phone_call" -> hangupPhone()
        "look_at_screen" -> com.meera.ai.automation.ScreenVision.look(args)
        "task_verify", "task_status", "task_cancel" -> com.meera.ai.tasks.TaskManager.tool(name, args)
        else -> if (name.startsWith("termux_")) com.meera.ai.automation.TermuxBridge.tool(name, args)
            else com.meera.ai.reminders.ReminderTools.run(name, args) ?: ToolOut("Unknown tool: $name")
    }

    /** end_call: only if the USER'S own last words were the command (same rule as the camera tools). */
    private fun endCallTool(): ToolOut {
        if (!com.meera.ai.voice.EndCallCommands.match(lastUserText)) {
            return ToolOut("REFUSED: the user's last words were not an explicit command to end the call. The call continues. Do not say it ended.")
        }
        call.endFromTool()
        return ToolOut("OK. The call closes right after your reply. Say ONE short goodbye sentence now and nothing else.")
    }

    private fun hangupPhone(): ToolOut {
        if (!com.meera.ai.voice.EndCallCommands.match(lastUserText, phoneCall = true)) {
            return ToolOut("REFUSED: the user's last words were not an explicit command to hang up a phone call. Nothing was done.")
        }
        return com.meera.ai.automation.PhoneCallControl.hangUp()
    }

    private fun setReplyStyle(args: JSONObject): ToolOut {
        val st = args.optString("style").trim().lowercase()
        if (!com.meera.ai.ai.DetailMode.valid(st)) return ToolOut("Unknown style '$st'. Use short, auto or detailed.")
        settings.replyStyle = st
        val what = when (st) {
            "short" -> "SHORT: always answer briefly."
            "detailed" -> "DETAILED: always answer in full detail (in a call you may speak for 2-4 minutes)."
            else -> "AUTO: short answers normally, full detail whenever the user asks for it."
        }
        return ToolOut("Reply style saved: $what Keep using this mode for the rest of this conversation.")
    }

    /**
     * Live call tools open_eyes / close_eyes. Like confirm_pending, the app checks the USER's last words itself:
     * the camera changes only if they really were the command. Gemini alone can never open the camera.
     */
    private fun eyesTool(want: EyesCmd): ToolOut {
        val said = EyesCommands.match(lastUserText)
        if (said != want) {
            val w = if (want == EyesCmd.OPEN) "open" else "close"
            return ToolOut(
                "REFUSED: the user's last words were not an explicit command to $w the eyes. The camera was NOT changed. " +
                    "Do not claim it was, and do not try again unless the user clearly commands it."
            )
        }
        val msg = eyes.runCommand(want)
        return if (want == EyesCmd.OPEN && eyes.isOpen.value) ToolOut("$msg ${eyes.liveHint()}") else ToolOut(msg)
    }

    private fun remember(args: JSONObject): ToolOut {
        val fact = args.optString("fact").trim()
        if (fact.isBlank()) return ToolOut("Nothing to remember.")
        // The user asked for it, so normal facts are saved right away. Sensitive-looking ones still need a clear yes.
        if (MemoryRepo.looksSensitive(fact)) {
            return confirmThen("This looks sensitive (password, number or ID). Do you still want me to remember: \"$fact\"? (yes / no)") {
                memory.add("fact", fact)
                "Okay, saved to memory."
            }
        }
        if (!memory.isDuplicate(fact)) memory.add("fact", fact)
        return ToolOut("Saved to memory: \"$fact\".")
    }

    private fun forget(args: JSONObject): ToolOut {
        val about = args.optString("about").trim().lowercase()
        if (about.length < 3) return ToolOut("Tell me what to forget.")
        val hits = memory.items.value.filter { it.text.lowercase().contains(about) }.take(10)
        if (hits.isEmpty()) return ToolOut("I found no saved memory about \"$about\".")
        return confirmThen("Delete ${hits.size} saved memor${if (hits.size == 1) "y" else "ies"} about \"$about\"? (yes / no)") {
            hits.forEach { memory.delete(it.id) }
            "Deleted ${hits.size} memor${if (hits.size == 1) "y" else "ies"} about \"$about\"."
        }
    }

    private fun phone(args: JSONObject): ToolOut {
        val act = args.optString("action")
        if (Actions.needsConfirm(act)) {
            return confirmThen(Actions.describe(args)) {
                val r = Actions.run(app, args)
                log.value = r
                r
            }
        }
        val r = Actions.run(app, args)
        log.value = r
        return ToolOut(r)
    }

    /** Used by the Phone Automation screen: natural-language command -> tool calls. */
    suspend fun command(text: String): String {
        lastUserText = text
        interceptAnswer(text)?.let { return it }
        val s = settings
        return try {
            val r = gemini.generate(
                s.model, Persona.system("chat"), listOf(ChatMsg("user", text)),
                0.2, tools = Persona.tools
            )
            if (r.calls.isEmpty()) {
                Mood.strip(r.text).ifBlank { "I did not find an action to run." }
            } else {
                val sb = StringBuilder()
                for (c in r.calls) {
                    if (sb.isNotEmpty()) sb.append("\n")
                    sb.append(handleCall(c.name, c.args).text)
                }
                sb.toString()
            }
        } catch (e: GeminiException) {
            e.message ?: "Error"
        }
    }
}
