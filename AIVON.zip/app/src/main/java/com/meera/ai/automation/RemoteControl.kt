package com.meera.ai.automation

import android.Manifest
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.RemoteInput
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.BatteryManager
import android.os.Bundle
import android.service.notification.StatusBarNotification
import androidx.core.content.ContextCompat
import com.meera.ai.MainActivity
import com.meera.ai.Meera
import com.meera.ai.ai.Agent
import com.meera.ai.ai.ChatMsg
import com.meera.ai.ai.Mood
import com.meera.ai.ai.Persona
import com.meera.ai.tasks.TaskManager
import com.meera.ai.voice.CallState
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock

/**
 * WhatsApp Remote: the owner sends "PIN command" from his OTHER number; AIVON reads the WhatsApp notification, checks that the
 * sender is a trusted contact AND the PIN is right, runs the command with Meera's normal tools and answers through the
 * notification's reply action. No website, no server. Everything else (other chats, groups, wrong PIN) is ignored.
 */
object RemoteControl {
    private val WA = setOf("com.whatsapp", "com.whatsapp.w4b")
    private const val CHANNEL = "aivon_remote"
    private const val ID_STATUS = 4210
    private const val ID_FALLBACK = 4211
    private const val ID_LOCK = 4212

    private val seen = LinkedHashSet<String>()
    private val replyActions = HashMap<String, Notification.Action>()
    private val sentEcho = ArrayList<Pair<Long, Int>>()
    private val stamps = ArrayList<Long>()
    private val mutex = Mutex()

    private class Parsed(val sender: String, val text: String, val time: Long, val group: Boolean, val numbers: List<String>, val reply: Notification.Action?)

    // ───────────── entry point from MeeraNotificationListener ─────────────

    fun onNotification(sbn: StatusBarNotification) {
        if (sbn.packageName !in WA) return
        if (!RemoteStore.enabled.value && !RemoteStore.testWaiting.value) return
        val p = try { parse(sbn) } catch (e: Exception) { null } ?: return
        val key = p.sender + "|" + p.time + "|" + p.text.hashCode()
        synchronized(seen) {
            if (!seen.add(key)) return
            if (seen.size > 80) seen.remove(seen.first())
        }
        if (isOwnEcho(p.text)) return
        Meera.scope.launch(Dispatchers.Main.immediate) {
            mutex.withLock {
                try { handle(p) } catch (e: CancellationException) { throw e } catch (e: Exception) { RemoteStore.logRejected("error: " + (e.message ?: e.javaClass.simpleName)) }
            }
        }
    }

    private fun parse(sbn: StatusBarNotification): Parsed? {
        val n = sbn.notification ?: return null
        if (n.flags and Notification.FLAG_GROUP_SUMMARY != 0) return null
        val e = n.extras ?: return null
        val title = e.getCharSequence(Notification.EXTRA_TITLE)?.toString()?.trim().orEmpty()
        var text = (e.getCharSequence(Notification.EXTRA_BIG_TEXT) ?: e.getCharSequence(Notification.EXTRA_TEXT))?.toString().orEmpty()
        var time = sbn.postTime
        var msgSender: String? = null
        @Suppress("DEPRECATION")
        val msgs = e.getParcelableArray(Notification.EXTRA_MESSAGES)
        if (msgs != null && msgs.isNotEmpty()) {
            val b = msgs[msgs.size - 1] as? Bundle
            if (b != null) {
                b.getCharSequence("text")?.toString()?.let { text = it }
                msgSender = b.getCharSequence("sender")?.toString()
                time = b.getLong("time", time)
            }
        }
        val conv = e.getCharSequence(Notification.EXTRA_CONVERSATION_TITLE)?.toString()
        val group = e.getBoolean(Notification.EXTRA_IS_GROUP_CONVERSATION, false) ||
            (!conv.isNullOrBlank() && !msgSender.isNullOrBlank() && !msgSender.equals(title, ignoreCase = true))
        val nums = ArrayList<String>()
        try {
            @Suppress("DEPRECATION")
            val people = e.getParcelableArrayList<android.app.Person>(Notification.EXTRA_PEOPLE_LIST)
            people?.forEach { pr -> pr.uri?.let { if (it.startsWith("tel:")) nums.add(it.removePrefix("tel:")) } }
        } catch (ex: Exception) { }
        try {
            @Suppress("DEPRECATION")
            e.getStringArray(Notification.EXTRA_PEOPLE)?.forEach { if (it.startsWith("tel:")) nums.add(it.removePrefix("tel:")) }
        } catch (ex: Exception) { }
        val reply = n.actions?.firstOrNull { a -> a.remoteInputs?.isNotEmpty() == true }
        return Parsed(title, text.trim(), time, group, nums, reply)
    }

    private fun sameNumber(a: String, b: String): Boolean {
        val x = a.filter { it.isDigit() }
        val y = b.filter { it.isDigit() }
        return x.isNotEmpty() && y.isNotEmpty() && (x.endsWith(y.takeLast(9)) || y.endsWith(x.takeLast(9)))
    }

    // ───────────── checks ─────────────

    private suspend fun handle(p: Parsed) {
        val st = RemoteStore
        val contact = st.contacts.value.firstOrNull { it.name.trim().equals(p.sender.trim(), ignoreCase = true) }
        if (st.testWaiting.value) {
            st.lastSeen.value = "Message aaya  |  sender: \"" + p.sender + "\"  |  " +
                (if (p.group) "GROUP chat (ignored)" else if (contact != null) "trusted contact: YES" else "trusted contact: NO (naam form se match nahi karta)") +
                (if (p.numbers.isNotEmpty()) "  |  number: " + p.numbers.first() else "  |  number notification main nahi") +
                "  |  reply button: " + (if (p.reply != null) "mila" else "NAHI mila")
        }
        if (!st.enabled.value) return
        if (p.group) return
        if (contact == null) return // other chats: ignored silently, never logged, never sent anywhere
        if (p.reply != null) replyActions[contact.id] = p.reply
        if (contact.paused) return
        if (p.numbers.isNotEmpty() && contact.number.isNotBlank() && p.numbers.none { sameNumber(it, contact.number) }) {
            st.logRejected(contact.name + ": number mismatch (ignored)")
            return
        }
        if (st.isLocked()) { st.logRejected(contact.name + ": remote control is locked (ignored)"); return }
        val m = Regex("^\\s*(\\d{4,8})\\s*(.*)$", RegexOption.DOT_MATCHES_ALL).find(p.text)
        if (m == null) { st.logRejected(contact.name + ": message without PIN (ignored)"); return }
        val pin = m.groupValues[1]
        val cmd = m.groupValues[2].trim()
        if (!st.checkPin(contact, pin)) {
            val locked = st.wrongPin()
            st.logRejected(contact.name + ": wrong PIN" + if (locked) " (3 times: locked for 30 minutes)" else "")
            if (locked) notify(ID_LOCK, "AIVON remote locked", "3 wrong PINs from " + contact.name + ". Remote control is locked for 30 minutes.")
            return
        }
        st.clearWrong()
        if (cmd.isBlank()) { reply(contact, pin, "PIN ke baad command likhein, jaise: status"); return }
        val now = System.currentTimeMillis()
        val tooMany = synchronized(stamps) { stamps.removeAll { now - it > 3_600_000L }; if (stamps.size >= 20) true else { stamps.add(now); false } }
        if (tooMany) { reply(contact, pin, "Ek ghante main 20 se zyada commands nahi chalte. Thori der baad likhein."); return }
        st.logHistory("-> " + cmd)
        val answer = execute(cmd)
        st.logHistory("<- " + answer.take(120))
        reply(contact, pin, answer)
    }

    // ───────────── doing the command ─────────────

    private suspend fun execute(cmd: String): String {
        val low = cmd.lowercase().trim()
        return when {
            Regex("^(stop|ruk\\s*jao|ruk\\s*ja|rok\\s*do|cancel)\\b").containsMatchIn(low) -> {
                TaskManager.cancelAll()
                "Theek hai, sab rok diya."
            }
            Meera.awaiting != null && Regex("^(haan|han|yes|ji|ok)\\b").containsMatchIn(low) -> withGate { Meera.interceptAnswer("haan") ?: "Ab koi sawal intezar main nahi." }
            Meera.awaiting != null && Regex("^(nahi|nahin|no|na)\\b").containsMatchIn(low) -> Meera.interceptAnswer("nahi") ?: "Theek hai."
            low.startsWith("status") -> statusText()
            Regex("call").containsMatchIn(low) && Regex("aa\\s*jao|par\\s*aa|shuru|start|lagao|karo").containsMatchIn(low) && !low.contains("band") -> startCall()
            else -> runAgent(cmd)
        }
    }

    /** Screen control from remote works only if the owner allowed it for remote (the gate is opened for this one command only). */
    private suspend fun <T> withGate(block: suspend () -> T): T {
        val was = Meera.accessGate.value
        val open = !was && RemoteStore.allowScreen.value
        if (open) Meera.accessGate.value = true
        try { return block() } finally { if (open) Meera.accessGate.value = was }
    }

    private suspend fun runAgent(cmd: String): String {
        var asked = ""
        return try {
            val res = withGate {
                Agent.run(
                    Meera.settings.model, Persona.system("remote"), listOf(ChatMsg("user", cmd)), 0.4, Persona.tools, 1024
                ) { ev, t -> if (ev == "ask") asked = t }
            }
            if (res.askedUser) asked + "\n\nConfirm karne ke liye likhein: HAAN <PIN>"
            else Mood.split(res.text).first.ifBlank { "Kaam ho gaya, lekin koi jawab nahi mila." }
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            "Error: " + (e.message ?: e.javaClass.simpleName)
        }
    }

    private suspend fun startCall(): String {
        val ctx = Meera.app
        if (ContextCompat.checkSelfPermission(ctx, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            return "Call shuru nahi ho saki: microphone ki ijazat nahi. App kholkar Call screen se ijazat dein."
        }
        if (Meera.call.state.value != CallState.Idle && Meera.call.state.value != CallState.Error) return "Call pehle se chal rahi hai."
        return try {
            Meera.call.start()
            delay(1800)
            if (Meera.call.state.value == CallState.Error) {
                openAppNotification("Call shuru karne ke liye dabayein")
                "Call shuru nahi hui (" + Meera.call.status.value + "). Android background se call kabhi nahi shuru karne deta; phone par notification bheji hai."
            } else "Call shuru kar di."
        } catch (e: Exception) {
            openAppNotification("Call shuru karne ke liye dabayein")
            "Android ne background se call shuru nahi hone di. Phone par notification bheji hai: use dabayein aur Call screen se shuru karein."
        }
    }

    private fun statusText(): String {
        val ctx = Meera.app
        val bm = ctx.getSystemService(BatteryManager::class.java)
        val pct = try { bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY) } catch (e: Exception) { -1 }
        val bi = ctx.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val stt = bi?.getIntExtra(BatteryManager.EXTRA_STATUS, -1) ?: -1
        val charging = stt == BatteryManager.BATTERY_STATUS_CHARGING || stt == BatteryManager.BATTERY_STATUS_FULL
        val cm = ctx.getSystemService(ConnectivityManager::class.java)
        val online = cm?.getNetworkCapabilities(cm.activeNetwork)?.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET) == true
        val t = TaskManager.tasks.value.firstOrNull()
        return "AIVON status\n" +
            "Battery: " + (if (pct >= 0) "$pct%" else "?") + (if (charging) " (charge ho rahi hai)" else "") + "\n" +
            "Internet: " + (if (online) "chal raha hai" else "NAHI") + "\n" +
            "Call: " + Meera.call.state.value + "\n" +
            "Termux: " + (if (!Meera.settings.termuxEnabled) "band" else if (TermuxBridge.installed(ctx) && TermuxBridge.hasPermission(ctx)) "tayyar" else "setup adhura") + "\n" +
            "Screen control: " + (if (Meera.accessGate.value) "on" else if (RemoteStore.allowScreen.value) "remote ke liye allowed" else "off") + "\n" +
            "Aakhri kaam: " + (t?.let { it.title + " (" + it.status + (if (it.verified) ", verified" else "") + ")" } ?: "koi nahi")
    }

    // ───────────── answering on WhatsApp ─────────────

    private fun isOwnEcho(text: String): Boolean {
        val now = System.currentTimeMillis()
        synchronized(sentEcho) {
            sentEcho.removeAll { now - it.first > 300_000L }
            return sentEcho.any { it.second == text.trim().hashCode() }
        }
    }

    private fun send(a: Notification.Action, part: String): Boolean = try {
        val ri = a.remoteInputs
        if (ri == null || ri.isEmpty()) false else {
            val intent = Intent()
            val b = Bundle()
            for (r in ri) b.putCharSequence(r.resultKey, part)
            RemoteInput.addResultsToIntent(ri, intent, b)
            a.actionIntent.send(Meera.app, 0, intent)
            synchronized(sentEcho) { sentEcho.add(Pair(System.currentTimeMillis(), part.trim().hashCode())) }
            true
        }
    } catch (e: Exception) {
        false
    }

    private suspend fun reply(c: RemoteContact, pin: String, text0: String) {
        // never send the PIN or secrets back
        var text = TermuxBridge.mask(text0)
        if (pin.isNotEmpty()) text = text.replace(pin, "****")
        val parts = ArrayList<String>()
        var rest = text.trim()
        while (rest.isNotEmpty() && parts.size < 3) {
            if (rest.length <= 600) { parts.add(rest); rest = "" } else {
                var cut = rest.lastIndexOf('\n', 600)
                if (cut < 200) cut = 600
                parts.add(rest.take(cut).trim())
                rest = rest.drop(cut).trim()
            }
        }
        val a = replyActions[c.id]
        var ok = false
        if (a != null) {
            for ((i, part) in parts.withIndex()) {
                ok = send(a, part)
                if (!ok) break
                if (i < parts.size - 1) delay(900)
            }
        }
        if (!ok) {
            notify(ID_FALLBACK, "AIVON remote: " + c.name, text.take(400))
            RemoteStore.logRejected("reply could not go through WhatsApp (shown as a notification instead)")
        }
    }

    // ───────────── notifications ─────────────

    private fun channel() {
        val nm = Meera.app.getSystemService(NotificationManager::class.java)
        if (nm.getNotificationChannel(CHANNEL) == null) {
            nm.createNotificationChannel(NotificationChannel(CHANNEL, "AIVON remote control", NotificationManager.IMPORTANCE_DEFAULT))
        }
    }

    private fun notify(id: Int, title: String, text: String) {
        try {
            channel()
            val open = PendingIntent.getActivity(Meera.app, 0, Intent(Meera.app, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
            val n = Notification.Builder(Meera.app, CHANNEL)
                .setSmallIcon(android.R.drawable.stat_notify_chat).setContentTitle(title).setContentText(text)
                .setStyle(Notification.BigTextStyle().bigText(text)).setContentIntent(open).setAutoCancel(true).build()
            Meera.app.getSystemService(NotificationManager::class.java).notify(id, n)
        } catch (e: Exception) { }
    }

    private fun openAppNotification(title: String) = notify(ID_FALLBACK, title, "AIVON ko kholne ke liye dabayein.")

    /** The ongoing "Remote control active" notice with a Pause button (shown only while the switch is on). */
    fun syncStatusNotification() {
        try {
            val nm = Meera.app.getSystemService(NotificationManager::class.java)
            if (!RemoteStore.enabled.value) { nm.cancel(ID_STATUS); return }
            channel()
            val pause = PendingIntent.getBroadcast(Meera.app, 7, Intent(Meera.app, RemoteReceiver::class.java), PendingIntent.FLAG_IMMUTABLE)
            val open = PendingIntent.getActivity(Meera.app, 0, Intent(Meera.app, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
            val n = Notification.Builder(Meera.app, CHANNEL)
                .setSmallIcon(android.R.drawable.stat_notify_chat).setContentTitle("Remote control active")
                .setContentText("WhatsApp se aap ke commands sun rahi hai").setOngoing(true).setContentIntent(open)
                .addAction(Notification.Action.Builder(null, "Pause", pause).build()).build()
            nm.notify(ID_STATUS, n)
        } catch (e: Exception) { }
    }
}

/** The Pause button of the "Remote control active" notification. */
class RemoteReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        RemoteStore.setEnabled(false)
    }
}
