package com.meera.ai.ui.orb

import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.BlendMode
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.lerp
import kotlin.math.cos
import kotlin.math.sin

internal const val TAU = 6.2831855f
internal const val RAD2DEG = 57.29578f
internal const val PIF = 3.1415927f

/** One frame of data every style draws from. Drawing happens in a 340 x 340 design square centred on (0, 0). */
internal class OrbFrame(
    val t: Float,
    val lvl: Float,
    val rot: Float,
    val state: OrbState,
    val pal: OrbPal,
    val hack: Color,
    val glow: Float,
    val low: Boolean,
    val mem: OrbMemory
) {
    val speak: Boolean get() = state == OrbState.SPEAK
    val listen: Boolean get() = state == OrbState.LISTEN
    val think: Boolean get() = state == OrbState.THINK
    val idle: Boolean get() = state == OrbState.IDLE
}

internal fun Color.mixW(w: Float): Color = lerp(this, Color.White, w.coerceIn(0f, 1f))
internal fun Color.dk(w: Float): Color = Color(red * w, green * w, blue * w, 1f)
internal fun Color.al(a: Float): Color = copy(alpha = a.coerceIn(0f, 1f))

/** Soft additive glow. Skipped completely in Low effects mode. */
internal fun DrawScope.glow(f: OrbFrame, x: Float, y: Float, r: Float, col: Color, a: Float) {
    if (f.low) return
    val aa = (a * f.glow).coerceIn(0f, 1f)
    if (aa < 0.004f || r < 1f) return
    val c = Offset(x, y)
    drawCircle(
        Brush.radialGradient(listOf(col.al(aa), col.al(0f)), center = c, radius = r),
        radius = r, center = c, blendMode = BlendMode.Plus
    )
}

/** Like glow, but in Low effects mode draws a small plain translucent disc instead (so shapes stay visible). */
internal fun DrawScope.soft(f: OrbFrame, x: Float, y: Float, r: Float, col: Color, a: Float) {
    if (f.low) drawCircle(col.al(a * 0.5f), r * 0.5f, Offset(x, y)) else glow(f, x, y, r, col, a)
}

/** 4-point sparkle star. */
internal fun DrawScope.sparkle(f: OrbFrame, x: Float, y: Float, s: Float, col: Color, a: Float) {
    val c = col.al(a)
    drawLine(c, Offset(x - s, y), Offset(x + s, y), strokeWidth = 1f)
    drawLine(c, Offset(x, y - s), Offset(x, y + s), strokeWidth = 1f)
    glow(f, x, y, s * 1.8f, col, a * 0.5f)
}

/** Radius of the wobbling blob at angle th. */
internal fun blobR(th: Float, r0: Float, amp: Float, t: Float, sp: Float): Float =
    r0 + amp * (sin(2f * th + t * 1.1f * sp) * 0.5f + sin(3f * th - t * 1.7f * sp) * 0.35f + sin(5f * th + t * 2.3f * sp) * 0.25f)

/** Wobbling closed blob (sum of sines) around (0, 0). */
internal fun blobPath(p: Path, r0: Float, amp: Float, t: Float, sp: Float) {
    p.reset()
    val steps = 60
    for (i in 0..steps) {
        val th = i.toFloat() / steps * TAU
        val r = blobR(th, r0, amp, t, sp)
        val x = cos(th) * r
        val y = sin(th) * r
        if (i == 0) p.moveTo(x, y) else p.lineTo(x, y)
    }
    p.close()
}

/** Rotates a point around Y then X. Writes x, y, z into out at offset o. */
internal fun rotYX(x: Float, y: Float, z: Float, ay: Float, ax: Float, out: FloatArray, o: Int) {
    val ca = cos(ay)
    val sa = sin(ay)
    val x1 = x * ca + z * sa
    val z1 = -x * sa + z * ca
    val cx = cos(ax)
    val sx = sin(ax)
    out[o] = x1
    out[o + 1] = y * cx - z1 * sx
    out[o + 2] = y * sx + z1 * cx
}
