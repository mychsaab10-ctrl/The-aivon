package com.meera.ai.tasks

import android.content.Context
import android.content.Intent
import androidx.core.content.ContextCompat
import com.meera.ai.Meera
import com.meera.ai.ToolOut
import com.meera.ai.automation.ScreenControl
import com.meera.ai.automation.TermuxBridge
import com.meera.ai.ui.UiMsg
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject

enum class TStatus { RUNNING, WAITING, VERIFYING, DONE, FAILED, CANCELLED }

/** One piece of background work (everything Meera does for one request). */
data class TaskInfo(
    val id: Int,
    val title: String,
    val startedAt: Long,
    val endedAt: Long = 0L,
    val status: TStatus = TStatus.RUNNING,
    val steps: List<String> = emptyList(),
    val log: List<String> = emptyList(),
    val verified: Boolean = false,
    val summary: String = "",
    val lastActivity: Long = startedAt
) {
    val active: Boolean get() = status == TStatus.RUNNING || status == TStatus.WAITING || status == TStatus.VERIFYING
}

/**
 * Follows every action tool call (phone, screen, message, Termux) as a task, keeps the foreground notification and
 * the floating window up to date, and checks results for real with task_verify (the APP checks, not the model).
 */
object TaskManager {
    val tasks = MutableStateFlow<List<TaskInfo>>(emptyList())
    private var nextId = 1

    private val ACTION = setOf("phone_action", "screen_action", "send_message", "hangup_phone_call")
    private val CHANGING = setOf("termux_run", "termux_job_start", "termux_write_file", "termux_install")

    /** Tools that change something (used by the agent to ask for a check before it says "done"). */
    fun isActionTool(name: String): Boolean = name in ACTION || name in CHANGING

    fun verifyEnabled(): Boolean = Meera.settings.tasksEnabled

    private fun trackable(name: String): Boolean = name in ACTION || name.startsWith("termux_")

    private fun stepTitle(name: String, args: JSONObject): String = when (name) {
        "termux_run" -> "Termux: " + args.optString("command").lineSequence().firstOrNull().orEmpty().take(40)
        "termux_job_start" -> "Termux job: " + args.optString("command").take(36)
        "termux_job_status" -> "Termux job ka status"
        "termux_job_stop" -> "Termux job band"
        "termux_install" -> "Termux install: " + args.optString("packages").take(30)
        "termux_write_file" -> "File likh rahi hoon: " + args.optString("path").takeLast(30)
        "termux_read_file" -> "File padh rahi hoon: " + args.optString("path").takeLast(30)
        "termux_list" -> "Folder dekh rahi hoon"
        "termux_check" -> "Termux check"
        "termux_open_app" -> "Termux khol rahi hoon"
        "screen_action" -> "Screen: " + args.optString("action").take(30)
        "phone_action" -> "Phone: " + args.optString("action").take(30)
        "send_message" -> "Message bhej rahi hoon"
        "hangup_phone_call" -> "Phone call band"
        else -> name
    }

    private fun update(id: Int, f: (TaskInfo) -> TaskInfo) {
        tasks.value = tasks.value.map { if (it.id == id) f(it) else it }
    }

    private fun ensureTask(first: String, now: Long): Int {
        val cur = tasks.value.firstOrNull { it.active && now - it.lastActivity < 120_000 }
        if (cur != null) return cur.id
        val t = TaskInfo(nextId++, first, now)
        tasks.value = (listOf(t) + tasks.value).take(20)
        return t.id
    }

    /** Wraps a tool call. Non-action tools (memory, reminders, time...) pass straight through. */
    suspend fun track(name: String, args: JSONObject, block: suspend () -> ToolOut): ToolOut {
        if (!Meera.settings.tasksEnabled || !trackable(name)) return block()
        val now = System.currentTimeMillis()
        val title = stepTitle(name, args)
        val id = ensureTask(title, now)
        update(id) { it.copy(status = TStatus.RUNNING, steps = it.steps + title, lastActivity = now) }
        startService()
        val out = try {
            block()
        } catch (e: CancellationException) {
            update(id) { it.copy(status = TStatus.CANCELLED, endedAt = System.currentTimeMillis(), log = (it.log + "stopped").takeLast(30)) }
            syncService()
            throw e
        } catch (e: Exception) {
            update(id) { it.copy(status = TStatus.FAILED, endedAt = System.currentTimeMillis(), log = (it.log + "x " + (e.message ?: "error")).takeLast(30)) }
            syncService()
            throw e
        }
        val failed = Regex("^(FAILED|REFUSED|TIMEOUT|Unknown|Termux (is|control) |No |Could not|Error)").containsMatchIn(out.text.trim()) ||
            out.text.contains("non-zero exit code")
        val line = (if (out.ask) "? " else if (failed) "x " else "ok ") + out.text.replace('\n', ' ').take(90)
        update(id) {
            it.copy(
                status = if (out.ask) TStatus.WAITING else TStatus.RUNNING,
                log = (it.log + line).takeLast(30),
                lastActivity = System.currentTimeMillis()
            )
        }
        scheduleFinish(id)
        return out
    }

    /** A task with no new step for a while is finished: DONE, or FAILED when its last step failed. A waiting question expires. */
    private fun scheduleFinish(id: Int) {
        Meera.scope.launch {
            delay(22_000)
            val t = tasks.value.firstOrNull { it.id == id } ?: return@launch
            val idle = System.currentTimeMillis() - t.lastActivity
            if (t.status == TStatus.RUNNING && idle >= 20_000) {
                val failed = t.log.lastOrNull()?.startsWith("x ") == true
                finish(id, if (failed) TStatus.FAILED else TStatus.DONE, if (failed) "Last step failed." else if (t.verified) "Verified." else "Done, but not verified.")
            } else if (t.status == TStatus.WAITING && idle >= 125_000) {
                finish(id, TStatus.CANCELLED, "No answer: cancelled.")
            } else if (t.active) {
                scheduleFinish(id)
            }
        }
    }

    private fun finish(id: Int, status: TStatus, summary: String, verified: Boolean? = null) {
        update(id) { it.copy(status = status, endedAt = System.currentTimeMillis(), summary = summary, verified = verified ?: it.verified) }
        persist()
        syncService()
    }

    // ───────────── foreground service ─────────────

    private fun startService() {
        try {
            val app = Meera.app
            ContextCompat.startForegroundService(app, Intent(app, MeeraTaskService::class.java))
        } catch (e: Exception) { /* Android may refuse from the background: the floating window still works */ }
    }

    private fun syncService() {
        if (tasks.value.none { it.active }) {
            try { Meera.app.stopService(Intent(Meera.app, MeeraTaskService::class.java)) } catch (e: Exception) { }
        }
    }

    // ───────────── tools: task_verify / task_status / task_cancel ─────────────

    suspend fun tool(name: String, args: JSONObject): ToolOut = when (name) {
        "task_status" -> status()
        "task_cancel" -> { cancelAll(); ToolOut("Everything was stopped.") }
        else -> verify(args)
    }

    private fun status(): ToolOut {
        val l = tasks.value
        if (l.isEmpty()) return ToolOut("No task yet.")
        val t = l.first()
        return ToolOut(
            "Latest task: " + t.title + " | status: " + t.status + (if (t.verified) " (verified)" else "") +
                " | steps: " + t.steps.size + " | " + t.log.takeLast(3).joinToString(" / ")
        )
    }

    /** The app does the check itself with real evidence. */
    private suspend fun verify(args: JSONObject): ToolOut {
        val method = args.optString("method").trim().lowercase()
        val target = args.optString("target").trim()
        val expected = args.optString("expected").trim()
        val cur = tasks.value.firstOrNull { it.active } ?: tasks.value.firstOrNull()
        if (cur != null && cur.active) update(cur.id) { it.copy(status = TStatus.VERIFYING, lastActivity = System.currentTimeMillis()) }
        val pass: Boolean
        val why: String
        when (method) {
            "termux_exit" -> {
                val e = TermuxBridge.lastExit
                pass = e == 0
                why = if (e == null) "no exit code known (the command did not finish)" else "last Termux exit code = $e"
            }
            "termux_output" -> {
                pass = expected.isNotBlank() && TermuxBridge.lastOut.contains(expected, ignoreCase = true)
                why = if (pass) "the output contains the expected text" else "the output does NOT contain the expected text"
            }
            "termux_file" -> {
                val (ok, msg) = TermuxBridge.fileCheck(target, expected)
                pass = ok
                why = "file $target: $msg"
            }
            "screen_text" -> {
                val txt = ScreenControl.run(JSONObject().put("action", "read_screen")).text
                pass = expected.isNotBlank() && txt.contains(expected, ignoreCase = true)
                why = if (pass) "the expected text is on the screen" else "the expected text is NOT on the screen (or screen control is off)"
            }
            else -> return ToolOut("Unknown method '$method'. Use termux_exit, termux_output, termux_file or screen_text.")
        }
        if (cur != null) {
            update(cur.id) { it.copy(log = (it.log + (if (pass) "ok verified: " else "x not verified: ") + why).takeLast(30)) }
            finish(cur.id, if (pass) TStatus.DONE else TStatus.FAILED, (if (pass) "Verified: " else "Not verified: ") + why, pass)
        }
        return ToolOut(if (pass) "VERIFIED: $why." else "NOT VERIFIED: $why. Do not say the task is done; tell the user honestly what failed.")
    }

    // ───────────── controls ─────────────

    /** Stop button, notification action, "ruk jao": cancel chat work, Termux jobs and every running task. */
    fun cancelAll() {
        try { Meera.chat.stop() } catch (e: Exception) { }
        TermuxBridge.stopAll()
        Meera.awaiting = null
        val now = System.currentTimeMillis()
        tasks.value = tasks.value.map { if (it.active) it.copy(status = TStatus.CANCELLED, endedAt = now, summary = "Stopped by the user.") else it }
        persist()
        syncService()
    }

    /** True when a task is running right now. */
    fun anyActive(): Boolean = tasks.value.any { it.active }

    /** The window's Haan / Nahi buttons: answer the waiting question exactly like a spoken yes or no. */
    fun answer(yes: Boolean) {
        val res = Meera.interceptAnswer(if (yes) "haan" else "nahi") ?: return
        val cur = tasks.value.firstOrNull { it.status == TStatus.WAITING }
        if (cur != null) update(cur.id) { it.copy(status = TStatus.RUNNING, log = (it.log + "ok " + res.take(90)).takeLast(30), lastActivity = System.currentTimeMillis()) }
        try { Meera.chat.messages.add(UiMsg("model", res)) } catch (e: Exception) { }
        scheduleFinish(cur?.id ?: return)
    }

    fun clearHistory() {
        tasks.value = tasks.value.filter { it.active }
        persist()
    }

    /** A harmless 3-step demo so the user can see the window and the notification. */
    fun demo() {
        Meera.scope.launch {
            val now = System.currentTimeMillis()
            val t = TaskInfo(nextId++, "Test: demo kaam", now)
            tasks.value = (listOf(t) + tasks.value).take(20)
            startService()
            for (s in listOf("Step 1: tayyari", "Step 2: kaam chal raha hai", "Step 3: natija dekh rahi hoon")) {
                update(t.id) { it.copy(steps = it.steps + s, log = (it.log + "ok " + s).takeLast(30), lastActivity = System.currentTimeMillis()) }
                delay(1500)
            }
            update(t.id) { it.copy(status = TStatus.VERIFYING) }
            delay(1200)
            finish(t.id, TStatus.DONE, "Demo verified.", true)
        }
    }

    // ───────────── history on the phone ─────────────

    private fun prefs() = Meera.app.getSharedPreferences("meera_tasks", Context.MODE_PRIVATE)

    fun load() {
        try {
            val a = JSONArray(prefs().getString("h", "[]"))
            val l = ArrayList<TaskInfo>()
            for (i in 0 until a.length()) {
                val o = a.getJSONObject(i)
                l.add(
                    TaskInfo(
                        id = nextId++, title = o.optString("t"), startedAt = o.optLong("s"), endedAt = o.optLong("e"),
                        status = try { TStatus.valueOf(o.optString("st")) } catch (e: Exception) { TStatus.DONE },
                        verified = o.optBoolean("v"), summary = o.optString("m")
                    )
                )
            }
            tasks.value = l
        } catch (e: Exception) { }
    }

    private fun persist() {
        try {
            val a = JSONArray()
            for (t in tasks.value.filter { !it.active }.take(20)) {
                a.put(JSONObject().put("t", t.title).put("s", t.startedAt).put("e", t.endedAt).put("st", t.status.name).put("v", t.verified).put("m", t.summary))
            }
            prefs().edit().putString("h", a.toString()).apply()
        } catch (e: Exception) { }
    }
}
