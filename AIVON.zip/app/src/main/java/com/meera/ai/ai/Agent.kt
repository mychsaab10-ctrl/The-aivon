package com.meera.ai.ai

import com.meera.ai.Meera
import com.meera.ai.tasks.TaskManager
import org.json.JSONArray

/** Final answer of an agent run (the last model reply after all tool rounds). */
class AgentResult(val text: String, val sources: List<String>, val finish: String, val askedUser: Boolean)

/**
 * Multi-step tool work for chat: run a tool, give the RESULT back to Gemini, let it decide the next step.
 * (Before this, chat ran the tools once and never showed the results to the model. The Live call already did.)
 * Results go back as plain text lines "TOOL RESULT name: ..." so the Gemini client does not need to change.
 */
object Agent {
    const val MAX_ROUNDS = 8

    /**
     * [onEvent] gets ("text", model words) for words said between tool rounds, ("tool", result) for every tool result
     * and ("ask", question) when the user must answer yes or no first (the run then stops).
     */
    suspend fun run(
        model: String,
        system: String,
        history: List<ChatMsg>,
        temperature: Double,
        tools: JSONArray?,
        maxOutputTokens: Int? = null,
        onEvent: (String, String) -> Unit
    ): AgentResult {
        val h = ArrayList(history)
        var attach: List<Attach> = emptyList()
        var acted = false
        var verified = false
        var nudged = false
        var last: GenResult? = null
        var round = 0
        while (round < MAX_ROUNDS) {
            round++
            val r = Meera.gemini.generate(model, system, h, temperature, attachments = attach, tools = tools, maxOutputTokens = maxOutputTokens)
            attach = emptyList()
            last = r
            if (r.calls.isEmpty()) {
                // A task ran but nothing proved it worked: ask the model once to verify before it says "done".
                if (acted && !verified && !nudged && r.text.isNotBlank() && TaskManager.verifyEnabled()) {
                    nudged = true
                    h.add(ChatMsg("model", r.text))
                    h.add(ChatMsg("user", "SYSTEM: before you tell the user the task is done, check it with task_verify " +
                        "(method termux_exit, termux_output, termux_file or screen_text). Then give the final answer. If it is not verified, say so honestly."))
                    continue
                }
                return AgentResult(r.text, r.sources, r.finish, false)
            }
            if (r.text.isNotBlank()) onEvent("text", r.text)
            val results = StringBuilder()
            for (c in r.calls) {
                if (TaskManager.isActionTool(c.name)) acted = true
                if (c.name == "task_verify") verified = true
                val out = Meera.handleCall(c.name, c.args)
                if (out.ask) {
                    onEvent("ask", out.text)
                    return AgentResult("", r.sources, r.finish, true)
                }
                onEvent("tool", out.text)
                if (out.image != null) attach = attach + out.image
                results.append("TOOL RESULT ").append(c.name).append(": ").append(out.text.take(3500)).append('\n')
            }
            val called = r.calls.joinToString("; ") { it.name + "(" + it.args.toString().take(300) + ")" }
            h.add(ChatMsg("model", (if (r.text.isNotBlank()) r.text + "\n" else "") + "CALLED " + called))
            h.add(ChatMsg("user", results.toString().trim()))
        }
        val l = last
        return AgentResult(
            (l?.text ?: "").ifBlank { "I stopped after $MAX_ROUNDS steps. Tell me to continue if you want more." },
            l?.sources ?: emptyList(), l?.finish ?: "", false
        )
    }
}
