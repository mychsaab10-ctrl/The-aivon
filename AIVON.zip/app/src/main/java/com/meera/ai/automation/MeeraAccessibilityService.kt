package com.meera.ai.automation

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.AccessibilityServiceInfo
import android.graphics.Bitmap
import android.content.Intent
import android.view.Display
import java.io.ByteArrayOutputStream
import java.util.concurrent.Executors
import kotlin.coroutines.resume
import kotlinx.coroutines.TimeoutCancellationException
import kotlinx.coroutines.delay
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withTimeout
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import com.meera.ai.Meera
import com.meera.ai.ToolOut
import org.json.JSONObject

/** A screenshot for Meera's eyes: JPEG bytes, or an honest error text. */
class ShotResult(val jpeg: ByteArray?, val error: String?, val width: Int, val height: Int)

/**
 * Optional screen control. It does NOTHING by itself: it only reacts to calls that come from the
 * Meera app after the user (1) enabled the service in Android Settings and (2) switched on
 * "Allow screen control" inside Meera. Taps and message sending also need a spoken/typed "yes" (or "haan") first.
 */
class MeeraAccessibilityService : AccessibilityService() {

    override fun onServiceConnected() {
        instance = this
        Meera.aura.onA11yChanged() // Meera Aura can now draw over other apps through this service
        com.meera.ai.tasks.TaskWindow.onServiceChanged()
    }

    override fun onUnbind(intent: Intent?): Boolean {
        instance = null
        Meera.aura.onA11yChanged()
        com.meera.ai.tasks.TaskWindow.onServiceChanged()
        return super.onUnbind(intent)
    }

    override fun onDestroy() {
        instance = null
        Meera.aura.onA11yChanged()
        com.meera.ai.tasks.TaskWindow.onServiceChanged()
        super.onDestroy()
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    fun readScreen(): String {
        val root = rootInActiveWindow ?: return ""
        val sb = StringBuilder()
        fun walk(n: AccessibilityNodeInfo?, depth: Int) {
            if (n == null || sb.length > 6000 || depth > 40) return
            if (n.isPassword) return // never read password fields
            val t = n.text?.toString() ?: n.contentDescription?.toString()
            if (!t.isNullOrBlank()) sb.append(t).append('\n')
            for (i in 0 until n.childCount) walk(n.getChild(i), depth + 1)
        }
        walk(root, 0)
        return sb.toString().trim()
    }

    private fun clickNode(n: AccessibilityNodeInfo): Boolean {
        var cur: AccessibilityNodeInfo? = n
        while (cur != null) {
            if (cur.isClickable && cur.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return true
            cur = cur.parent
        }
        return false
    }

    fun clickText(text: String): Boolean {
        val root = rootInActiveWindow ?: return false
        for (n in root.findAccessibilityNodeInfosByText(text)) {
            if (clickNode(n)) return true
        }
        return false
    }

    /**
     * Taps the Send button of WhatsApp / the SMS app. Only works while that app is in front,
     * so it can never tap "Send" inside some other app.
     */
    fun tapSend(kind: String): Boolean {
        val root = rootInActiveWindow ?: return false
        val pkg = root.packageName?.toString() ?: return false
        val rightApp = if (kind == "whatsapp") pkg.startsWith("com.whatsapp")
        else (pkg.contains("messag") || pkg.contains("mms") || pkg.contains("sms"))
        if (!rightApp) return false
        val ids = if (kind == "whatsapp") listOf("$pkg:id/send")
        else listOf("$pkg:id/send_message_button_icon", "$pkg:id/send_button", "$pkg:id/send_button1", "$pkg:id/send")
        for (id in ids) {
            val nodes = root.findAccessibilityNodeInfosByViewId(id) ?: continue
            for (n in nodes) if (clickNode(n)) return true
        }
        for (label in listOf("Send", "Send message", "Send SMS", "भेजें")) {
            for (n in root.findAccessibilityNodeInfosByText(label)) {
                val d = (n.contentDescription ?: n.text)?.toString()?.lowercase().orEmpty()
                if (d.startsWith("send") || d.startsWith("भेजें")) {
                    if (clickNode(n)) return true
                }
            }
        }
        return false
    }

    /** Replaces the text of the currently focused input field. */
    /** Taps an on-screen "End call" / "Hang up" button (exact label match so "Send" or "Friend" are never hit). */
    fun tapHangUp(): Boolean {
        val root = rootInActiveWindow ?: return false
        val labels = setOf("end call", "hang up", "leave", "leave call", "decline", "end", "end voice call", "disconnect")
        for (label in labels) {
            val nodes = root.findAccessibilityNodeInfosByText(label) ?: continue
            for (n in nodes) {
                val t = n.text?.toString()?.trim()?.lowercase()
                val d = n.contentDescription?.toString()?.trim()?.lowercase()
                if ((t == label || d == label) && clickNode(n)) return true
            }
        }
        return false
    }

    fun typeText(text: String): Boolean {
        val root = rootInActiveWindow ?: return false
        val node = root.findFocus(AccessibilityNodeInfo.FOCUS_INPUT) ?: return false
        val args = android.os.Bundle()
        args.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text)
        return node.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)
    }

    // ───────────── Screen vision (Android 11+) ─────────────

    private val shotExec by lazy { Executors.newSingleThreadExecutor() }

    /** Takes one screenshot, scales it to at most 1280 px and compresses it to JPEG (about 70 percent quality). Never saved to disk. */
    suspend fun captureScreen(): ShotResult {
        if (android.os.Build.VERSION.SDK_INT < 30) {
            return ShotResult(null, "Seeing the screen needs Android 11 or newer (reading the screen text still works).", 0, 0)
        }
        val cap = try { serviceInfo.capabilities } catch (e: Exception) { 0 }
        if (cap and AccessibilityServiceInfo.CAPABILITY_CAN_TAKE_SCREENSHOT == 0) {
            return ShotResult(null, "The accessibility service has no screenshot permission yet. Switch the AIVON service OFF and ON once in Android Settings.", 0, 0)
        }
        var r = shootOnce()
        if (r.error == "RETRY") { delay(1100); r = shootOnce() }
        return if (r.error == "RETRY") ShotResult(null, "Screenshots are being taken too quickly. Try again in a moment.", 0, 0) else r
    }

    private suspend fun shootOnce(): ShotResult = try {
        withTimeout(4000) {
            suspendCancellableCoroutine<ShotResult> { cont ->
                takeScreenshot(Display.DEFAULT_DISPLAY, shotExec, object : AccessibilityService.TakeScreenshotCallback {
                    override fun onSuccess(r: AccessibilityService.ScreenshotResult) {
                        val out = try {
                            val hb = r.hardwareBuffer
                            val wrapped = Bitmap.wrapHardwareBuffer(hb, r.colorSpace)
                            val soft = wrapped?.copy(Bitmap.Config.ARGB_8888, false)
                            wrapped?.recycle()
                            hb.close()
                            if (soft == null) ShotResult(null, "Could not read the screenshot.", 0, 0) else encodeShot(soft)
                        } catch (e: Exception) {
                            ShotResult(null, "Could not process the screenshot: " + (e.message ?: ""), 0, 0)
                        }
                        if (cont.isActive) cont.resume(out)
                    }

                    override fun onFailure(errorCode: Int) {
                        val msg = when (errorCode) {
                            AccessibilityService.ERROR_TAKE_SCREENSHOT_INTERVAL_TIME_SHORT -> "RETRY"
                            AccessibilityService.ERROR_TAKE_SCREENSHOT_SECURE_WINDOW -> "This screen is protected by Android, so I cannot see it."
                            AccessibilityService.ERROR_TAKE_SCREENSHOT_NO_ACCESSIBILITY_ACCESS -> "The accessibility service is not allowed to take screenshots."
                            AccessibilityService.ERROR_TAKE_SCREENSHOT_INVALID_DISPLAY, AccessibilityService.ERROR_TAKE_SCREENSHOT_INVALID_WINDOW -> "Android could not find a screen to capture."
                            else -> "Android could not take the screenshot (error $errorCode)."
                        }
                        if (cont.isActive) cont.resume(ShotResult(null, msg, 0, 0))
                    }
                })
            }
        }
    } catch (e: TimeoutCancellationException) {
        ShotResult(null, "The screenshot took too long.", 0, 0)
    } catch (e: Exception) {
        ShotResult(null, "Screenshot failed: " + (e.message ?: e.javaClass.simpleName), 0, 0)
    }

    private fun encodeShot(bmp: Bitmap): ShotResult {
        val maxSide = 1280f
        val k = minOf(1f, maxSide / maxOf(bmp.width, bmp.height))
        val scaled = if (k < 1f) Bitmap.createScaledBitmap(bmp, (bmp.width * k).toInt(), (bmp.height * k).toInt(), true) else bmp
        val bos = ByteArrayOutputStream()
        scaled.compress(Bitmap.CompressFormat.JPEG, 70, bos)
        val w = scaled.width
        val h = scaled.height
        if (scaled !== bmp) scaled.recycle()
        bmp.recycle()
        return ShotResult(bos.toByteArray(), null, w, h)
    }

    /** A single tap at pixel coordinates (used by the see-and-act loop for icons without text). */
    fun tapXY(x: Float, y: Float): Boolean {
        val p = android.graphics.Path()
        p.moveTo(x, y)
        val g = android.accessibilityservice.GestureDescription.Builder()
            .addStroke(android.accessibilityservice.GestureDescription.StrokeDescription(p, 0L, 60L))
            .build()
        return dispatchGesture(g, null, null)
    }


    /** A swipe gesture in the middle of the screen (dir: up, down, left, right). */
    fun swipe(dir: String): Boolean {
        val dm = resources.displayMetrics
        val w = dm.widthPixels.toFloat()
        val h = dm.heightPixels.toFloat()
        val p = android.graphics.Path()
        when (dir) {
            "up" -> { p.moveTo(w / 2, h * 0.70f); p.lineTo(w / 2, h * 0.30f) }
            "down" -> { p.moveTo(w / 2, h * 0.30f); p.lineTo(w / 2, h * 0.70f) }
            "left" -> { p.moveTo(w * 0.80f, h / 2); p.lineTo(w * 0.20f, h / 2) }
            "right" -> { p.moveTo(w * 0.20f, h / 2); p.lineTo(w * 0.80f, h / 2) }
            else -> return false
        }
        val g = android.accessibilityservice.GestureDescription.Builder()
            .addStroke(android.accessibilityservice.GestureDescription.StrokeDescription(p, 0L, 300L))
            .build()
        return dispatchGesture(g, null, null)
    }

    fun scroll(forward: Boolean): Boolean {
        val root = rootInActiveWindow ?: return false
        fun find(n: AccessibilityNodeInfo?): AccessibilityNodeInfo? {
            if (n == null) return null
            if (n.isScrollable) return n
            for (i in 0 until n.childCount) find(n.getChild(i))?.let { return it }
            return null
        }
        val target = find(root) ?: return false
        return target.performAction(
            if (forward) AccessibilityNodeInfo.ACTION_SCROLL_FORWARD else AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD
        )
    }

    companion object {
        @Volatile var instance: MeeraAccessibilityService? = null
        fun isEnabled() = instance != null
    }
}

object ScreenControl {
    /** Never claims more than Android confirmed. Taps first ask the user (yes / no). */
    fun run(args: JSONObject): ToolOut {
        if (!Meera.accessGate.value) return ToolOut("Blocked: screen control is switched off inside Meera. Ask the user to turn it on in the Phone Automation screen.")
        val svc = MeeraAccessibilityService.instance
            ?: return ToolOut("Blocked: Meera's accessibility service is not enabled in Android Settings.")
        return when (val a = args.optString("action")) {
            "read_screen" -> ToolOut(svc.readScreen().take(3000).ifBlank { "The screen has no readable text." })
            "back" -> res(svc.performGlobalAction(AccessibilityService.GLOBAL_ACTION_BACK), "Back")
            "home" -> res(svc.performGlobalAction(AccessibilityService.GLOBAL_ACTION_HOME), "Home")
            "recents" -> res(svc.performGlobalAction(AccessibilityService.GLOBAL_ACTION_RECENTS), "Recents")
            "notifications" -> res(svc.performGlobalAction(AccessibilityService.GLOBAL_ACTION_NOTIFICATIONS), "Notification shade")
            "quick_settings" -> res(svc.performGlobalAction(AccessibilityService.GLOBAL_ACTION_QUICK_SETTINGS), "Quick settings")
            "power_menu" -> res(svc.performGlobalAction(AccessibilityService.GLOBAL_ACTION_POWER_DIALOG), "Power menu")
            "lock_screen" ->
                if (android.os.Build.VERSION.SDK_INT >= 28) res(svc.performGlobalAction(AccessibilityService.GLOBAL_ACTION_LOCK_SCREEN), "Lock screen")
                else ToolOut("Failed: locking the screen needs Android 9 or newer.")
            "screenshot" ->
                if (android.os.Build.VERSION.SDK_INT >= 28) res(svc.performGlobalAction(AccessibilityService.GLOBAL_ACTION_TAKE_SCREENSHOT), "Screenshot")
                else ToolOut("Failed: screenshots need Android 9 or newer.")
            "swipe_up", "swipe_down", "swipe_left", "swipe_right" -> res(svc.swipe(a.removePrefix("swipe_")), "Swipe ${a.removePrefix("swipe_")}")
            "type_text" -> {
                val t = args.optString("text")
                if (t.isBlank()) ToolOut("Failed: no text given.")
                else res(svc.typeText(t), "Typing into the focused field (replaces its text)")
            }
            "scroll_down" -> res(svc.scroll(true), "Scroll down")
            "scroll_up" -> res(svc.scroll(false), "Scroll up")
            "click" -> {
                val t = args.optString("text")
                if (t.isBlank()) ToolOut("Failed: no element text given.")
                else Meera.confirmThen("Tap the element \"$t\" on the screen? (yes / no)") {
                    if (svc.clickText(t)) "Tap performed on \"$t\" (Android confirmed)."
                    else "No tappable element named \"$t\" was found."
                }
            }
            "tap_xy" -> {
                val x = args.optDouble("x", -1.0).toFloat()
                val y = args.optDouble("y", -1.0).toFloat()
                val dm = svc.resources.displayMetrics
                if (x < 0f || y < 0f || x > dm.widthPixels || y > dm.heightPixels) {
                    ToolOut("Failed: x and y must be inside the screen (" + dm.widthPixels + " x " + dm.heightPixels + " pixels).")
                } else Meera.confirmThen("Tap the screen at (" + x.toInt() + ", " + y.toInt() + ")? (yes / no)") {
                    if (svc.tapXY(x, y)) "Tap at (" + x.toInt() + ", " + y.toInt() + "): Android reported the gesture was performed."
                    else "Tap at (" + x.toInt() + ", " + y.toInt() + "): Android reported failure."
                }
            }
            else -> ToolOut("Unsupported screen action: $a")
        }
    }

    private fun res(ok: Boolean, what: String) =
        ToolOut(if (ok) "$what: Android reported the gesture was performed." else "$what: Android reported failure.")
}
