package com.meera.ai.ui

import android.content.Intent
import android.graphics.BitmapFactory
import android.provider.Settings
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Button
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.meera.ai.Meera
import com.meera.ai.automation.MeeraAccessibilityService
import com.meera.ai.automation.ScreenVision
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

/** Phone Automation: lets Meera look at the screen (screenshot) and a Test button that shows what she sees. */
@Composable
fun ScreenVisionCard() {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val gate by Meera.accessGate.collectAsState()
    var on by remember { mutableStateOf(Meera.settings.visionEnabled) }
    var busy by remember { mutableStateOf(false) }
    var thumb by remember { mutableStateOf<androidx.compose.ui.graphics.ImageBitmap?>(null) }
    var said by remember { mutableStateOf("") }
    val a11y = MeeraAccessibilityService.isEnabled()

    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        SectionTitle("Screen vision (Meera can SEE the screen)")
        Text(
            "Not only text: Meera takes a screenshot and looks at images, icons, videos and layouts. Needs Android 11 or newer and the switch above. " +
                "A short notice shows every time, nothing is saved, protected screens (banking) stay unseen, max 30 per hour. " +
                "If you enabled the Accessibility service before this update, switch it OFF and ON once so Android grants the screenshot permission.",
            fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("Meera screen dekh sake (screenshot)", fontSize = 14.sp, modifier = Modifier.weight(1f))
            Switch(checked = on, onCheckedChange = { on = it; Meera.settings.visionEnabled = it })
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(enabled = on && gate && a11y && !busy, onClick = {
                busy = true; thumb = null; said = "In 5 seconds switch to another app... then Meera looks."
                scope.launch {
                    delay(5000)
                    val (jpeg, text) = ScreenVision.test()
                    if (jpeg != null) thumb = BitmapFactory.decodeByteArray(jpeg, 0, jpeg.size)?.asImageBitmap()
                    said = text
                    busy = false
                }
            }) { Text(if (busy) "Looking..." else "Test: dekho") }
            OutlinedButton(onClick = {
                try { ctx.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (e: Exception) { }
            }) { Text("Accessibility settings") }
        }
        val t = thumb
        if (t != null) {
            Image(
                t, contentDescription = "What Meera saw",
                modifier = Modifier.widthIn(max = 180.dp).heightIn(max = 320.dp).clip(RoundedCornerShape(12.dp)),
                contentScale = ContentScale.Fit
            )
        }
        if (said.isNotBlank()) Text(said, fontSize = 13.sp, modifier = Modifier.fillMaxWidth())
    }
}
