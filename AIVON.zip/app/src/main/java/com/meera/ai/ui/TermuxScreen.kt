@file:OptIn(ExperimentalMaterial3Api::class)

package com.meera.ai.ui

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.meera.ai.Meera
import com.meera.ai.automation.TermuxBridge
import com.meera.ai.automation.TermuxHistory
import com.meera.ai.tasks.TaskManager
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlinx.coroutines.launch

private const val SETUP1 = "mkdir -p ~/.termux && echo \"allow-external-apps=true\" >> ~/.termux/termux.properties && termux-reload-settings"
private const val SETUP2 = "pkg install -y termux-api tmux"

/** Settings -> Termux control: switch, checks (tick or cross), setup commands, test, history, emergency stop. */
@Composable
fun TermuxScreen(onBack: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var enabled by remember { mutableStateOf(Meera.settings.termuxEnabled) }
    var installed by remember { mutableStateOf(TermuxBridge.installed(ctx)) }
    var allowed by remember { mutableStateOf(TermuxBridge.hasPermission(ctx)) }
    var testResult by remember { mutableStateOf<String?>(null) } // null = not tested, "ok" = works, else the problem
    var testing by remember { mutableStateOf(false) }
    val history by TermuxHistory.items.collectAsState()

    val permLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { ok -> allowed = ok }
    LaunchedEffect(Unit) { installed = TermuxBridge.installed(ctx); allowed = TermuxBridge.hasPermission(ctx) }

    fun copy(label: String, text: String) {
        (ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager).setPrimaryClip(ClipData.newPlainText(label, text))
        Meera.toast("Copied. Paste it in Termux.")
    }

    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 4.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) { Icon(Icons.Filled.ArrowBack, contentDescription = "Back") }
            Text("Termux control", fontSize = 20.sp, color = MaterialTheme.colorScheme.primary)
        }
        Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Text(
                "With this on, Meera can run commands in your Termux when you ask, read the result and tell you honestly if it worked. " +
                    "Risky commands (delete, kill, send data out, sudo...) always ask you yes or no first. It is OFF until you switch it on.",
                fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Termux control", fontSize = 16.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
                Switch(checked = enabled, onCheckedChange = { enabled = it; Meera.settings.termuxEnabled = it })
            }

            Text("Checks", fontSize = 15.sp, fontWeight = FontWeight.SemiBold, color = MaterialTheme.colorScheme.primary)
            CheckRow(installed, "Termux is installed (F-Droid or GitHub version, not Google Play)")
            CheckRow(allowed, "Android permission 'Run commands in Termux environment' is allowed")
            CheckRow(testResult == "ok", if (testResult == null) "Test command (echo ok) not run yet" else if (testResult == "ok") "Test command works" else "Test failed: $testResult")
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = { permLauncher.launch(TermuxBridge.PERMISSION_NAME) }, enabled = !allowed) { Text("Allow permission") }
                Button(onClick = {
                    testing = true
                    scope.launch {
                        installed = TermuxBridge.installed(ctx); allowed = TermuxBridge.hasPermission(ctx)
                        val r = TermuxBridge.exec("echo ok", null, 15)
                        testResult = when {
                            r.error != null -> r.error
                            r.timedOut -> "no answer: is allow-external-apps on, and did you restart Termux?"
                            r.stdout.trim() == "ok" -> "ok"
                            else -> "unexpected answer"
                        }
                        testing = false
                    }
                }, enabled = !testing) { Text(if (testing) "Testing..." else "Test connection") }
            }
            OutlinedButton(onClick = { installed = TermuxBridge.installed(ctx); allowed = TermuxBridge.hasPermission(ctx) }) { Text("Check again") }

            Text("One-time setup (run in Termux)", fontSize = 15.sp, fontWeight = FontWeight.SemiBold, color = MaterialTheme.colorScheme.primary)
            Text("1. Install Termux from F-Droid or GitHub. Open it once.", fontSize = 13.sp)
            Text("2. Paste this in Termux, then close Termux fully and open it again:", fontSize = 13.sp)
            CodeBox(SETUP1) { copy("setup", SETUP1) }
            Text("3. Optional tools for more features:", fontSize = 13.sp)
            CodeBox(SETUP2) { copy("setup", SETUP2) }
            Text("4. Tap 'Allow permission' above. 5. Set the battery of AIVON and Termux to Unrestricted.", fontSize = 13.sp)

            Button(
                onClick = { TaskManager.cancelAll(); Meera.toast("Everything stopped.") },
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFB3402F)),
                modifier = Modifier.fillMaxWidth()
            ) { Text("EMERGENCY STOP (jobs and tasks)") }

            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("History (this phone only)", fontSize = 15.sp, fontWeight = FontWeight.SemiBold, color = MaterialTheme.colorScheme.primary, modifier = Modifier.weight(1f))
                OutlinedButton(onClick = { TermuxHistory.clear() }, enabled = history.isNotEmpty()) { Text("Clear") }
            }
            if (history.isEmpty()) Text("No commands yet.", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            val fmt = remember { SimpleDateFormat("dd MMM HH:mm", Locale.getDefault()) }
            for (h in history.take(15)) {
                Column(Modifier.fillMaxWidth()) {
                    Text(fmt.format(Date(h.time)) + "   exit=" + (h.exit?.toString() ?: "?"), fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Text(h.command, fontSize = 12.sp, fontFamily = FontFamily.Monospace)
                    if (h.out.isNotBlank()) Text(h.out, fontSize = 11.sp, fontFamily = FontFamily.Monospace, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 2)
                }
            }
        }
    }
}

@Composable
private fun CheckRow(ok: Boolean, text: String) {
    Row(verticalAlignment = Alignment.Top, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        Text(if (ok) "✅" else "❌", fontSize = 14.sp)
        Text(text, fontSize = 13.sp)
    }
}

@Composable
private fun CodeBox(code: String, onCopy: () -> Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
        Text(code, fontSize = 12.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.fillMaxWidth())
        OutlinedButton(onClick = onCopy) { Text("Copy") }
    }
}
