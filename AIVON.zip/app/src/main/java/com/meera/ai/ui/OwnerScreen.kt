package com.meera.ai.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun OwnerScreen(onBack: () -> Unit) {
    SubScreen("Owner details", onBack) {
        GlowCard(Modifier.fillMaxWidth()) {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("App Name:", color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 13.sp)
                Text("AIVON", fontWeight = FontWeight.Bold, fontSize = 22.sp, color = MaterialTheme.colorScheme.primary)
                Line()
                Text("Assistant:", color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 13.sp)
                Text("Meera", fontWeight = FontWeight.Bold, fontSize = 22.sp, color = MaterialTheme.colorScheme.onSurface)
                Line()
                Text("Developed By:", color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 13.sp)
                Text("CH ADIL", fontWeight = FontWeight.Bold, fontSize = 22.sp, color = MaterialTheme.colorScheme.onSurface)
                Line()
                Text("AIVON ek personal AI voice assistant hai, jo CH ADIL ne banaya hai.", fontSize = 14.sp, color = MaterialTheme.colorScheme.onSurface)
                Line()
                Text("© 2026 CH ADIL - All Rights Reserved.", fontWeight = FontWeight.Bold, fontSize = 14.sp, color = MaterialTheme.colorScheme.onSurface)
            }
        }
    }
}

@Composable
private fun Line() {
    Box(Modifier.fillMaxWidth().height(1.dp).background(MaterialTheme.colorScheme.outline).padding(vertical = 2.dp))
}
