package com.meera.ai.ui

import android.content.Intent
import android.provider.Settings
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.app.NotificationManagerCompat
import com.meera.ai.Meera
import com.meera.ai.ai.ChatMsg
import com.meera.ai.ai.GeminiException
import com.meera.ai.automation.Actions
import com.meera.ai.automation.ScreenControl
import com.meera.ai.automation.MeeraAccessibilityService
import com.meera.ai.automation.MeeraNotificationListener
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import org.json.JSONObject

@Composable
fun AutomationScreen(onBack: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val log by Meera.log.collectAsState()
    val gate by Meera.accessGate.collectAsState()
    val notifs by MeeraNotificationListener.recent.collectAsState()
    var cmd by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var hour by remember { mutableStateOf("") }
    var minute by remember { mutableStateOf("") }
    var timerMin by remember { mutableStateOf("") }
    var clickText by remember { mutableStateOf("") }
    val a11yOn = MeeraAccessibilityService.isEnabled()
    val notifOn = NotificationManagerCompat.getEnabledListenerPackages(ctx).contains(ctx.packageName)

    fun act(vararg kv: Pair<String, Any>) {
        val o = JSONObject(); kv.forEach { o.put(it.first, it.second) }
        Meera.scope.launch { Meera.log.value = Meera.handleCall("phone_action", o).text }
    }
    fun screen(a: String, text: String = "") {
        Meera.scope.launch { Meera.log.value = Meera.handleCall("screen_action", JSONObject().put("action", a).put("text", text)).text }
    }
    fun openSettings(action: String) = ctx.startActivity(Intent(action).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))

    SubScreen("Phone Automation", onBack) {
        Text(
            "Every action uses Android's official intents. \"Launched\" only means Android accepted the request - Meera cannot see what happens next. Before a message, call or tap, Meera asks you: answer \"yes\" or \"no\" here (or in chat/call). Example: send hello to Ali on WhatsApp.",
            color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 13.sp
        )
        SectionTitle("Command (Roman Urdu / English)")
        OutlinedTextField(cmd, { cmd = it }, Modifier.fillMaxWidth(), label = { Text("for example: search songs on YouTube, or navigate to the airport") })
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
            PremiumButton(
                enabled = cmd.isNotBlank() && !busy,
                onClick = { busy = true; scope.launch { Meera.log.value = Meera.command(cmd); busy = false } }
            ) { Text(if (busy) "Working…" else "Run") }
            DictateButton { cmd = it }
        }

        SectionTitle("Quick actions")
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            PremiumOutlinedButton(onClick = { act("action" to "open_app", "query" to "YouTube") }) { Text("YouTube") }
            PremiumOutlinedButton(onClick = { act("action" to "open_url", "query" to "google.com") }) { Text("Browser") }
            PremiumOutlinedButton(onClick = { act("action" to "open_camera") }) { Text("Camera") }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            PremiumOutlinedButton(onClick = { act("action" to "open_settings", "query" to "") }) { Text("Settings") }
            PremiumOutlinedButton(onClick = { act("action" to "maps_search", "query" to "restaurants near me") }) { Text("Maps") }
        }

        SectionTitle("Alarm / Timer")
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(hour, { hour = it.take(2) }, Modifier.weight(1f), label = { Text("Hour 0-23") }, singleLine = true, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number))
            OutlinedTextField(minute, { minute = it.take(2) }, Modifier.weight(1f), label = { Text("Min") }, singleLine = true, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number))
            PremiumButton(enabled = hour.toIntOrNull() in 0..23 && minute.toIntOrNull() in 0..59,
                onClick = { act("action" to "set_alarm", "hour" to hour.toInt(), "minute" to minute.toInt(), "label" to "Meera alarm") }) { Text("Alarm") }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(timerMin, { timerMin = it.take(3) }, Modifier.weight(1f), label = { Text("Timer (minutes)") }, singleLine = true, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number))
            PremiumButton(enabled = (timerMin.toIntOrNull() ?: 0) > 0,
                onClick = { act("action" to "set_timer", "seconds" to timerMin.toInt() * 60) }) { Text("Timer") }
        }

        SectionTitle("Result")
        Text(log.ifBlank { "—" }, color = MaterialTheme.colorScheme.onSurface)

        SectionTitle("Screen control (Accessibility) - optional")
        Text(
            "Service: ${if (a11yOn) "ON ✅" else "OFF"}. Meera reads or controls the screen only when you ask here and the switch below is ON. She asks before tapping.",
            fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        PremiumOutlinedButton(onClick = { openSettings(Settings.ACTION_ACCESSIBILITY_SETTINGS) }) { Text("Open Accessibility settings") }
        Row(verticalAlignment = Alignment.CenterVertically) {
            Switch(checked = gate, onCheckedChange = { Meera.accessGate.value = it })
            Text("  Allow Meera to control the screen (this session)")
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            PremiumOutlinedButton(enabled = gate && a11yOn, onClick = { screen("back") }) { Text("Back") }
            PremiumOutlinedButton(enabled = gate && a11yOn, onClick = { screen("home") }) { Text("Home") }
            PremiumOutlinedButton(enabled = gate && a11yOn, onClick = { screen("scroll_down") }) { Text("Scroll ↓") }
            PremiumOutlinedButton(enabled = gate && a11yOn, onClick = { screen("scroll_up") }) { Text("↑") }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(clickText, { clickText = it }, Modifier.weight(1f), label = { Text("Tap element with text") }, singleLine = true)
            PremiumButton(enabled = gate && a11yOn && clickText.isNotBlank(), onClick = { screen("click", clickText) }) { Text("Tap") }
        }
        ScreenVisionCard()
        PremiumButton(
            enabled = gate && a11yOn && !busy,
            onClick = {
                busy = true
                Meera.log.value = "In 5 seconds switch to another app… then the screen will be read."
                scope.launch {
                    delay(5000)
                    val txt = ScreenControl.run(JSONObject().put("action", "read_screen")).text
                    Meera.log.value = "Screen text:\n$txt"
                    busy = false
                }
            }
        ) { Text("Read screen (5 sec delay)") }
        PremiumButton(
            enabled = gate && a11yOn && !busy,
            onClick = {
                busy = true
                Meera.log.value = "In 5 seconds switch to another app… then Meera will explain the screen."
                scope.launch {
                    delay(5000)
                    val txt = ScreenControl.run(JSONObject().put("action", "read_screen")).text
                    Meera.log.value = try {
                        Meera.gemini.generate(
                            Meera.settings.model, null,
                            listOf(ChatMsg("user", "Explain in simple Roman Urdu (or English if the text is English) what is on this phone screen and what the user can do:\n\n$txt")), 0.3
                        ).text
                    } catch (e: GeminiException) { e.message ?: "Error" }
                    busy = false
                }
            }
        ) { Text("Explain screen (5 sec delay)") }

        SectionTitle("Notifications")
        Text(
            "Notification access: ${if (notifOn) "ON ✅" else "OFF"}. Notifications are only kept in memory, never saved or uploaded (unless you ask for a summary).",
            fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        PremiumOutlinedButton(onClick = { openSettings("android.settings.ACTION_NOTIFICATION_LISTENER_SETTINGS") }) { Text("Open Notification access settings") }
        if (notifOn && notifs.isNotEmpty()) {
            PremiumButton(enabled = !busy, onClick = {
                busy = true
                scope.launch {
                    val txt = notifs.take(15).joinToString("\n") { "- ${it.pkg}: ${it.title} - ${it.text}" }
                    Meera.log.value = try {
                        Meera.gemini.generate(
                            Meera.settings.model, null,
                            listOf(ChatMsg("user", "Summarize these phone notifications in simple Roman Urdu (or English), most important first:\n$txt")), 0.3
                        ).text
                    } catch (e: GeminiException) { e.message ?: "Error" }
                    busy = false
                }
            }) { Text("Summarize ${notifs.size} notifications") }
            notifs.take(10).forEach {
                Text("• ${it.title}: ${it.text}", fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurface, modifier = Modifier.padding(top = 2.dp))
            }
        }
    }
}
