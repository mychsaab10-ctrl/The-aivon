@file:OptIn(ExperimentalMaterial3Api::class)

package com.meera.ai.ui

import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.app.NotificationManagerCompat
import com.meera.ai.automation.RemoteContact
import com.meera.ai.automation.RemoteStore
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

private class EditState(val id: String?, var name: String, var number: String, var pin: String, var photo: String)

/** Settings -> WhatsApp Remote: trusted contacts (name, photo, number, PIN), switch, test and logs. */
@Composable
fun RemoteScreen(onBack: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val enabled by RemoteStore.enabled.collectAsState()
    val allowScreen by RemoteStore.allowScreen.collectAsState()
    val contacts by RemoteStore.contacts.collectAsState()
    val history by RemoteStore.history.collectAsState()
    val rejected by RemoteStore.rejected.collectAsState()
    val testing by RemoteStore.testWaiting.collectAsState()
    val lastSeen by RemoteStore.lastSeen.collectAsState()
    var editing by remember { mutableStateOf<EditState?>(null) }
    var deleting by remember { mutableStateOf<RemoteContact?>(null) }
    var notifOn by remember { mutableStateOf(notificationAccess(ctx)) }
    val fmt = remember { SimpleDateFormat("dd MMM HH:mm", Locale.getDefault()) }

    LaunchedEffect(Unit) { while (true) { notifOn = notificationAccess(ctx); delay(2000) } }
    DisposableEffect(Unit) { onDispose { RemoteStore.testWaiting.value = false } }

    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 4.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) { Icon(Icons.Filled.ArrowBack, contentDescription = "Back") }
            Text("WhatsApp Remote", fontSize = 20.sp, color = MaterialTheme.colorScheme.primary)
        }
        Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Text(
                "Apne DOOSRE number se is phone ke WhatsApp par message bhejein: PIN, phir command. Meera notification padhti hai, " +
                    "sahi naam aur sahi PIN ho to command chalati hai aur WhatsApp par hi jawab deti hai. Koi website ya server nahi. Shuru main band rehta hai.",
                fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("WhatsApp Remote", fontSize = 16.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
                Switch(checked = enabled, onCheckedChange = { RemoteStore.setEnabled(it) })
            }
            RemoteCheck(notifOn, "Notification access diya hua hai (WhatsApp ki notification padhne ke liye)")
            OutlinedButton(onClick = {
                try { ctx.startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (e: Exception) { }
            }) { Text("Notification access kholein") }
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("Remote ko screen control ki ijazat", fontSize = 14.sp)
                    Text("Band ho to remote se tap, scroll ya screen dekhna nahi hoga.", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                Switch(checked = allowScreen, onCheckedChange = { RemoteStore.setAllowScreen(it) })
            }

            Text("Trusted contacts (1 se 3)", fontSize = 15.sp, fontWeight = FontWeight.SemiBold, color = MaterialTheme.colorScheme.primary)
            if (contacts.isEmpty()) Text("Abhi koi contact nahi. Neeche se add karein.", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            for (c in contacts) {
                ContactCard(
                    c,
                    onEdit = { editing = EditState(c.id, c.name, c.number, "", c.photo) },
                    onPause = { RemoteStore.saveContacts(contacts.map { if (it.id == c.id) it.copy(paused = !it.paused) else it }) },
                    onDelete = { deleting = c }
                )
            }
            Button(enabled = contacts.size < 3, onClick = { editing = EditState(null, "", "", "", "") }, modifier = Modifier.fillMaxWidth()) {
                Text("Contact add karein")
            }

            Text("Test", fontSize = 15.sp, fontWeight = FontWeight.SemiBold, color = MaterialTheme.colorScheme.primary)
            Text(
                "Dabayein, phir doosre number se koi bhi message (jaise: test) bhejein. Yahan dikhega ke message aaya, naam pehchana gaya ya nahi, aur reply button mila ya nahi (90 second).",
                fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Button(enabled = !testing, onClick = {
                RemoteStore.lastSeen.value = null
                RemoteStore.testWaiting.value = true
                scope.launch { delay(90_000); RemoteStore.testWaiting.value = false }
            }) { Text(if (testing) "Intezar... (message bhejein)" else "Test shuru karein") }
            lastSeen?.let { Text(it, fontSize = 13.sp) }

            Text("Setup (ek baar)", fontSize = 15.sp, fontWeight = FontWeight.SemiBold, color = MaterialTheme.colorScheme.primary)
            Text(
                "1. Doosre number ko is phone ke contacts main EXACT wahi naam se save karein jo upar form main likha hai (kisi aur ke paas wo naam na ho).\n" +
                    "2. WhatsApp ki notification mute ya band na karein; chat screen par khuli ho to notification nahi aati.\n" +
                    "3. AIVON ki battery 'Unrestricted' rakhein.\n" +
                    "4. Message ka format:  PIN  command   (misal: 4821 status, 4821 call par aa jao, 4821 stop).\n" +
                    "5. Khatarnak kaam par Meera poochegi; jawab main likhein: HAAN  aur PIN (misal: HAAN 4821).",
                fontSize = 12.sp
            )

            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("History (sirf is phone par)", fontSize = 15.sp, fontWeight = FontWeight.SemiBold, color = MaterialTheme.colorScheme.primary, modifier = Modifier.weight(1f))
                OutlinedButton(onClick = { RemoteStore.clearLogs() }, enabled = history.isNotEmpty() || rejected.isNotEmpty()) { Text("Clear") }
            }
            if (history.isEmpty()) Text("Koi command nahi.", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            for (h in history.take(12)) Text(fmt.format(Date(h.time)) + "  " + h.text, fontSize = 12.sp)
            Text("Reject hui koshishein", fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
            if (rejected.isEmpty()) Text("Koi nahi.", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            for (h in rejected.take(12)) Text(fmt.format(Date(h.time)) + "  " + h.text, fontSize = 12.sp)
        }
    }

    editing?.let { st -> ContactDialog(st, onDismiss = { editing = null }) { e ->
        val id = e.id ?: System.currentTimeMillis().toString(36)
        val old = contacts.firstOrNull { it.id == id }
        val salt = if (e.pin.isNotEmpty()) RemoteStore.newSalt() else old?.salt.orEmpty()
        val hash = if (e.pin.isNotEmpty()) RemoteStore.hash(e.pin, salt) else old?.pinHash.orEmpty()
        val c = RemoteContact(id, e.name.trim(), e.number.filter { it.isDigit() }, e.photo, salt, hash, old?.paused ?: false)
        RemoteStore.saveContacts(if (old != null) contacts.map { if (it.id == id) c else it } else contacts + c)
        editing = null
    } }

    deleting?.let { c ->
        AlertDialog(
            onDismissRequest = { deleting = null },
            title = { Text("Contact hatayein?") },
            text = { Text(c.name + " ab Meera ko commands nahi bhej sakega.") },
            confirmButton = { TextButton(onClick = { RemoteStore.saveContacts(contacts.filter { it.id != c.id }); deleting = null }) { Text("Hatayein") } },
            dismissButton = { TextButton(onClick = { deleting = null }) { Text("Cancel") } }
        )
    }
}

private fun notificationAccess(ctx: Context): Boolean =
    NotificationManagerCompat.getEnabledListenerPackages(ctx).contains(ctx.packageName)

@Composable
private fun RemoteCheck(ok: Boolean, text: String) {
    Row(verticalAlignment = Alignment.Top, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        Text(if (ok) "✅" else "❌", fontSize = 14.sp)
        Text(text, fontSize = 13.sp)
    }
}

@Composable
private fun ContactCard(c: RemoteContact, onEdit: () -> Unit, onPause: () -> Unit, onDelete: () -> Unit) {
    val bmp = remember(c.photo) { if (c.photo.isNotBlank()) BitmapFactory.decodeFile(c.photo)?.asImageBitmap() else null }
    Column(Modifier.fillMaxWidth().background(MaterialTheme.colorScheme.surfaceVariant, androidx.compose.foundation.shape.RoundedCornerShape(16.dp)).padding(12.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            if (bmp != null) {
                Image(bmp, contentDescription = c.name, modifier = Modifier.size(52.dp).clip(CircleShape), contentScale = ContentScale.Crop)
            } else {
                Box(Modifier.size(52.dp).clip(CircleShape).background(MaterialTheme.colorScheme.primary), contentAlignment = Alignment.Center) {
                    Text(c.name.take(1).uppercase(), color = MaterialTheme.colorScheme.onPrimary, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                }
            }
            Column(Modifier.weight(1f)) {
                Text(c.name, fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
                Text(maskNumber(c.number), fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Text(if (c.paused) "Paused" else "Active", fontSize = 12.sp, color = if (c.paused) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.primary)
            }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.padding(top = 8.dp)) {
            OutlinedButton(onClick = onEdit) { Text("Edit") }
            OutlinedButton(onClick = onPause) { Text(if (c.paused) "Resume" else "Pause") }
            OutlinedButton(onClick = onDelete) { Text("Delete") }
        }
    }
}

private fun maskNumber(n: String): String = if (n.length > 6) "+" + n.take(3) + "••••" + n.takeLast(2) else if (n.isBlank()) "(number nahi)" else n

@Composable
private fun ContactDialog(st: EditState, onDismiss: () -> Unit, onSave: (EditState) -> Unit) {
    val ctx = LocalContext.current
    var name by remember { mutableStateOf(st.name) }
    var number by remember { mutableStateOf(st.number) }
    var pin by remember { mutableStateOf("") }
    var photo by remember { mutableStateOf(st.photo) }
    val newId = remember { st.id ?: System.currentTimeMillis().toString(36) }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null) savePhoto(ctx, uri, newId)?.let { photo = it }
    }
    val bmp = remember(photo) { if (photo.isNotBlank()) BitmapFactory.decodeFile(photo)?.asImageBitmap() else null }
    val pinOk = if (st.id == null) Regex("^\\d{4,8}$").matches(pin) else (pin.isEmpty() || Regex("^\\d{4,8}$").matches(pin))
    val ok = name.isNotBlank() && number.count { it.isDigit() } >= 8 && pinOk

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (st.id == null) "Contact add karein" else "Contact badlein") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.verticalScroll(rememberScrollState())) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    if (bmp != null) Image(bmp, contentDescription = null, modifier = Modifier.size(56.dp).clip(CircleShape), contentScale = ContentScale.Crop)
                    OutlinedButton(onClick = { picker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)) }) {
                        Text(if (bmp == null) "Photo chunein (optional)" else "Photo badlein")
                    }
                }
                OutlinedTextField(name, { name = it }, label = { Text("Naam (WhatsApp main jaisa dikhta hai)") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(
                    number, { number = it }, label = { Text("Number (country code ke saath, jaise +92300...)") }, singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone), modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    pin, { pin = it.filter { ch -> ch.isDigit() }.take(8) },
                    label = { Text(if (st.id == null) "Secret PIN (4 se 8 ginti)" else "Naya PIN (khali = purana rahega)") }, singleLine = true,
                    visualTransformation = PasswordVisualTransformation(),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword), modifier = Modifier.fillMaxWidth()
                )
                Text("PIN save nahi hota, sirf uska hash. Bhool jayein to naya PIN daal dein.", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        },
        confirmButton = {
            TextButton(enabled = ok, onClick = { onSave(EditState(st.id ?: newId, name, number, pin, photo)) }) { Text("Save") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}

private fun savePhoto(ctx: Context, uri: Uri, id: String): String? {
    try {
        val opts = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) }
        var sample = 1
        while (opts.outWidth / sample > 600 && opts.outHeight / sample > 600) sample *= 2
        val o2 = BitmapFactory.Options().apply { inSampleSize = sample }
        val bmp = ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, o2) } ?: return null
        val side = minOf(bmp.width, bmp.height)
        val sq = Bitmap.createBitmap(bmp, (bmp.width - side) / 2, (bmp.height - side) / 2, side, side)
        val out = Bitmap.createScaledBitmap(sq, 256, 256, true)
        val f = File(ctx.filesDir, "remote_$id.jpg")
        FileOutputStream(f).use { out.compress(Bitmap.CompressFormat.JPEG, 88, it) }
        return f.absolutePath
    } catch (e: Exception) {
        return null
    }
}
