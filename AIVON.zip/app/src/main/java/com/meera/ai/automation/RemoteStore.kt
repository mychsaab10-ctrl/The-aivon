package com.meera.ai.automation

import android.content.Context
import com.meera.ai.Meera
import java.security.MessageDigest
import java.security.SecureRandom
import kotlinx.coroutines.flow.MutableStateFlow
import org.json.JSONArray
import org.json.JSONObject

/** A trusted WhatsApp contact (the owner's other number). The PIN is never stored: only a salted SHA-256 hash. */
data class RemoteContact(
    val id: String,
    val name: String,
    val number: String,
    val photo: String,
    val salt: String,
    val pinHash: String,
    val paused: Boolean
)

class RemoteLog(val time: Long, val text: String)

/** Everything WhatsApp Remote remembers. Stored on this phone only. */
object RemoteStore {
    val contacts = MutableStateFlow<List<RemoteContact>>(emptyList())
    val history = MutableStateFlow<List<RemoteLog>>(emptyList())
    val rejected = MutableStateFlow<List<RemoteLog>>(emptyList())
    val enabled = MutableStateFlow(false)
    val allowScreen = MutableStateFlow(false)

    /** The Test button waits for a message and shows what arrived. */
    val testWaiting = MutableStateFlow(false)
    val lastSeen = MutableStateFlow<String?>(null)

    private val wrong = ArrayList<Long>()
    @Volatile private var lockedUntil = 0L

    private fun prefs() = Meera.app.getSharedPreferences("meera_remote", Context.MODE_PRIVATE)

    fun load() {
        try {
            val p = prefs()
            enabled.value = p.getBoolean("on", false)
            allowScreen.value = p.getBoolean("screen", false)
            lockedUntil = p.getLong("lockedUntil", 0L)
            val a = JSONArray(p.getString("contacts", "[]"))
            val l = ArrayList<RemoteContact>()
            for (i in 0 until a.length()) {
                val o = a.getJSONObject(i)
                l.add(RemoteContact(o.optString("id"), o.optString("name"), o.optString("number"), o.optString("photo"), o.optString("salt"), o.optString("hash"), o.optBoolean("paused")))
            }
            contacts.value = l
            history.value = readLogs(p.getString("hist", "[]"))
            rejected.value = readLogs(p.getString("rej", "[]"))
        } catch (e: Exception) { }
    }

    private fun readLogs(json: String?): List<RemoteLog> {
        val a = JSONArray(json ?: "[]")
        val l = ArrayList<RemoteLog>()
        for (i in 0 until a.length()) { val o = a.getJSONObject(i); l.add(RemoteLog(o.optLong("t"), o.optString("x"))) }
        return l
    }

    private fun writeLogs(l: List<RemoteLog>): String {
        val a = JSONArray()
        for (x in l) a.put(JSONObject().put("t", x.time).put("x", x.text))
        return a.toString()
    }

    fun setEnabled(v: Boolean) {
        enabled.value = v
        prefs().edit().putBoolean("on", v).apply()
        RemoteControl.syncStatusNotification()
    }

    fun setAllowScreen(v: Boolean) {
        allowScreen.value = v
        prefs().edit().putBoolean("screen", v).apply()
    }

    fun saveContacts(list: List<RemoteContact>) {
        contacts.value = list
        val a = JSONArray()
        for (c in list) a.put(JSONObject().put("id", c.id).put("name", c.name).put("number", c.number).put("photo", c.photo).put("salt", c.salt).put("hash", c.pinHash).put("paused", c.paused))
        prefs().edit().putString("contacts", a.toString()).apply()
    }

    fun newSalt(): String {
        val b = ByteArray(8)
        SecureRandom().nextBytes(b)
        return b.joinToString("") { "%02x".format(it) }
    }

    fun hash(pin: String, salt: String): String =
        MessageDigest.getInstance("SHA-256").digest("$salt:$pin".toByteArray()).joinToString("") { "%02x".format(it) }

    fun checkPin(c: RemoteContact, pin: String): Boolean {
        val a = hash(pin, c.salt)
        return MessageDigest.isEqual(a.toByteArray(), c.pinHash.toByteArray())
    }

    // ───────────── lock after 3 wrong PINs in 10 minutes ─────────────

    fun isLocked(): Boolean = System.currentTimeMillis() < lockedUntil

    /** Counts a wrong PIN. Returns true when this one locked remote control for 30 minutes. */
    @Synchronized
    fun wrongPin(): Boolean {
        val now = System.currentTimeMillis()
        wrong.removeAll { now - it > 600_000L }
        wrong.add(now)
        if (wrong.size >= 3) {
            lockedUntil = now + 1_800_000L
            wrong.clear()
            prefs().edit().putLong("lockedUntil", lockedUntil).apply()
            return true
        }
        return false
    }

    @Synchronized
    fun clearWrong() { wrong.clear() }

    // ───────────── logs (the PIN is never written here) ─────────────

    fun logHistory(text: String) {
        val l = (listOf(RemoteLog(System.currentTimeMillis(), text.take(300))) + history.value).take(40)
        history.value = l
        prefs().edit().putString("hist", writeLogs(l)).apply()
    }

    fun logRejected(text: String) {
        val l = (listOf(RemoteLog(System.currentTimeMillis(), text.take(200))) + rejected.value).take(40)
        rejected.value = l
        prefs().edit().putString("rej", writeLogs(l)).apply()
    }

    fun clearLogs() {
        history.value = emptyList()
        rejected.value = emptyList()
        prefs().edit().remove("hist").remove("rej").apply()
    }
}
