package com.meera.ai.tasks

import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.text.TextUtils
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import com.meera.ai.Meera
import com.meera.ai.automation.MeeraAccessibilityService
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

/**
 * The small floating window that shows what Meera is doing. It is added through the ACCESSIBILITY service
 * (TYPE_ACCESSIBILITY_OVERLAY), exactly like the Meera Aura border, so it never needs "Display over other apps".
 * Plain Android views only (no Compose inside an overlay).
 */
object TaskWindow {
    private var wm: WindowManager? = null
    private var root: LinearLayout? = null
    private var lp: WindowManager.LayoutParams? = null

    private var expanded = false
    private var minimized = false
    private var closedForTask = -1

    private var tvTitle: TextView? = null
    private var tvStep: TextView? = null
    private var tvLog: TextView? = null
    private var tvTime: TextView? = null
    private var bar: ProgressBar? = null
    private var rowButtons: LinearLayout? = null
    private var btnYes: TextView? = null
    private var btnNo: TextView? = null
    private var bubble: TextView? = null
    private var body: LinearLayout? = null

    fun start(scope: CoroutineScope) {
        scope.launch { TaskManager.tasks.collect { refresh() } }
        scope.launch {
            while (true) {
                delay(1000)
                if (root != null) bindTime()
            }
        }
    }

    /** Called when the accessibility service connects or disconnects. */
    fun onServiceChanged() {
        if (MeeraAccessibilityService.instance == null) dropViews() else refresh()
    }

    private fun dp(v: Int): Int {
        val d = (MeeraAccessibilityService.instance?.resources ?: Meera.app.resources).displayMetrics.density
        return (v * d).toInt()
    }

    private fun shouldShow(): Boolean {
        val s = Meera.settings
        if (!s.tasksEnabled || s.taskWindowMode == 2) return false
        val cur = TaskManager.tasks.value.firstOrNull { it.active }
        if (s.taskWindowMode == 1) return cur != null && cur.id != closedForTask
        return true
    }

    private fun refresh() {
        try {
            val svc = MeeraAccessibilityService.instance
            if (svc == null || !shouldShow()) { dropViews(); return }
            if (root == null) build(svc)
            bind()
        } catch (e: Exception) {
            dropViews()
        }
    }

    private fun dropViews() {
        try { root?.let { wm?.removeView(it) } } catch (e: Exception) { }
        root = null; lp = null; wm = null
        tvTitle = null; tvStep = null; tvLog = null; tvTime = null; bar = null
        rowButtons = null; btnYes = null; btnNo = null; bubble = null; body = null
    }

    private fun pill(ctx: android.content.Context, text: String, fill: Int, onClick: () -> Unit): TextView {
        val t = TextView(ctx)
        t.text = text
        t.setTextColor(Color.WHITE)
        t.textSize = 12f
        t.gravity = Gravity.CENTER
        t.setPadding(dp(10), dp(5), dp(10), dp(5))
        val g = GradientDrawable()
        g.cornerRadius = dp(12).toFloat()
        g.setColor(fill)
        t.background = g
        t.setOnClickListener { onClick() }
        return t
    }

    private fun build(svc: MeeraAccessibilityService) {
        val ctx: android.content.Context = svc
        val manager = ctx.getSystemService(android.content.Context.WINDOW_SERVICE) as WindowManager
        val width = if (Meera.settings.taskWindowSize == 0) dp(210) else dp(270)

        val card = LinearLayout(ctx)
        card.orientation = LinearLayout.VERTICAL
        card.setPadding(dp(12), dp(10), dp(12), dp(10))
        val bg = GradientDrawable()
        bg.cornerRadius = dp(18).toFloat()
        bg.setColor(Color.parseColor("#E60B1030"))
        bg.setStroke(dp(1), Color.parseColor("#663A3F94"))
        card.background = bg

        // minimised bubble
        val b = TextView(ctx)
        b.text = "A"
        b.setTextColor(Color.WHITE)
        b.textSize = 16f
        b.typeface = Typeface.DEFAULT_BOLD
        b.gravity = Gravity.CENTER
        b.visibility = View.GONE
        card.addView(b, LinearLayout.LayoutParams(dp(40), dp(40)))

        val content = LinearLayout(ctx)
        content.orientation = LinearLayout.VERTICAL

        val top = LinearLayout(ctx)
        top.orientation = LinearLayout.HORIZONTAL
        top.gravity = Gravity.CENTER_VERTICAL
        val brand = TextView(ctx)
        brand.text = "AIVON · Meera"
        brand.setTextColor(Color.parseColor("#7AB8FF"))
        brand.textSize = 11f
        top.addView(brand, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        val min = TextView(ctx)
        min.text = "—"
        min.setTextColor(Color.parseColor("#B4BCEB"))
        min.textSize = 16f
        min.setPadding(dp(8), 0, dp(8), 0)
        min.setOnClickListener { minimized = true; bind() }
        top.addView(min)
        val close = TextView(ctx)
        close.text = "✕"
        close.setTextColor(Color.parseColor("#B4BCEB"))
        close.textSize = 14f
        close.setPadding(dp(8), 0, 0, 0)
        close.setOnClickListener {
            closedForTask = TaskManager.tasks.value.firstOrNull { it.active }?.id ?: -2
            if (Meera.settings.taskWindowMode == 0) Meera.settings.taskWindowMode = 1
            refresh()
        }
        top.addView(close)
        content.addView(top)

        val title = TextView(ctx)
        title.setTextColor(Color.WHITE)
        title.textSize = 14f
        title.typeface = Typeface.DEFAULT_BOLD
        title.maxLines = 1
        title.ellipsize = TextUtils.TruncateAt.END
        content.addView(title)

        val stepRow = LinearLayout(ctx)
        stepRow.orientation = LinearLayout.HORIZONTAL
        val step = TextView(ctx)
        step.setTextColor(Color.parseColor("#B4BCEB"))
        step.textSize = 12f
        step.maxLines = 2
        step.ellipsize = TextUtils.TruncateAt.END
        stepRow.addView(step, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        val time = TextView(ctx)
        time.setTextColor(Color.parseColor("#8A90C8"))
        time.textSize = 11f
        stepRow.addView(time)
        content.addView(stepRow)

        val pb = ProgressBar(ctx, null, android.R.attr.progressBarStyleHorizontal)
        pb.max = 100
        content.addView(pb, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(6)))

        val log = TextView(ctx)
        log.setTextColor(Color.parseColor("#9DA5E0"))
        log.textSize = 11f
        log.maxLines = 2
        log.ellipsize = TextUtils.TruncateAt.END
        log.setPadding(0, dp(4), 0, 0)
        content.addView(log)

        val buttons = LinearLayout(ctx)
        buttons.orientation = LinearLayout.HORIZONTAL
        buttons.setPadding(0, dp(8), 0, 0)
        val stop = pill(ctx, "Stop", Color.parseColor("#B3402F")) { TaskManager.cancelAll() }
        val yes = pill(ctx, "Haan", Color.parseColor("#2F7D4F")) { TaskManager.answer(true) }
        val no = pill(ctx, "Nahi", Color.parseColor("#5A5F9E")) { TaskManager.answer(false) }
        buttons.addView(stop)
        val gap = { v: View -> (v.layoutParams as? LinearLayout.LayoutParams)?.leftMargin = dp(8) }
        buttons.addView(yes); gap(yes)
        buttons.addView(no); gap(no)
        content.addView(buttons)
        card.addView(content)

        val params = WindowManager.LayoutParams(
            width, WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or
                WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED,
            PixelFormat.TRANSLUCENT
        )
        params.gravity = Gravity.TOP or Gravity.START
        val sx = Meera.settings.taskWindowX
        val sy = Meera.settings.taskWindowY
        params.x = if (sx >= 0) sx else dp(12)
        params.y = if (sy >= 0) sy else dp(90)

        // drag to move; a short tap expands or collapses the log; a tap on the bubble opens it again
        var downX = 0f; var downY = 0f; var startX = 0; var startY = 0; var moved = false
        card.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> {
                    downX = e.rawX; downY = e.rawY; startX = params.x; startY = params.y; moved = false; true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (e.rawX - downX).toInt()
                    val dy = (e.rawY - downY).toInt()
                    if (Math.abs(dx) > dp(6) || Math.abs(dy) > dp(6)) moved = true
                    if (moved) {
                        params.x = (startX + dx).coerceAtLeast(0)
                        params.y = (startY + dy).coerceAtLeast(0)
                        try { manager.updateViewLayout(card, params) } catch (ex: Exception) { }
                    }
                    true
                }
                MotionEvent.ACTION_UP -> {
                    if (moved) {
                        Meera.settings.taskWindowX = params.x
                        Meera.settings.taskWindowY = params.y
                    } else if (minimized) {
                        minimized = false; bind()
                    } else {
                        expanded = !expanded; bind()
                    }
                    true
                }
                else -> false
            }
        }

        manager.addView(card, params)
        wm = manager; root = card; lp = params
        tvTitle = title; tvStep = step; tvLog = log; tvTime = time; bar = pb
        rowButtons = buttons; btnYes = yes; btnNo = no; bubble = b; body = content
    }

    private fun bind() {
        val card = root ?: return
        val t = TaskManager.tasks.value.firstOrNull { it.active } ?: TaskManager.tasks.value.firstOrNull()
        bubble?.visibility = if (minimized) View.VISIBLE else View.GONE
        body?.visibility = if (minimized) View.GONE else View.VISIBLE
        val icon = when {
            t == null -> "•"
            t.status == TStatus.RUNNING -> "⏳"
            t.status == TStatus.WAITING -> "❓"
            t.status == TStatus.VERIFYING -> "🔎"
            t.status == TStatus.DONE -> if (t.verified) "✅" else "⚠"
            t.status == TStatus.FAILED -> "❌"
            else -> "⏹"
        }
        tvTitle?.text = if (t == null) "Meera tayyar hai" else icon + " " + t.title
        tvStep?.text = when {
            t == null -> "Koi kaam nahi chal raha."
            t.active -> "Step " + t.steps.size + ": " + (t.steps.lastOrNull() ?: "")
            else -> t.summary.ifBlank { t.status.name }
        }
        tvLog?.text = if (t == null) "" else t.log.takeLast(2).joinToString("\n")
        tvLog?.visibility = if (expanded || (t != null && !t.active)) View.VISIBLE else View.GONE
        tvLog?.maxLines = if (expanded) 8 else 2
        bar?.isIndeterminate = t != null && t.status == TStatus.RUNNING
        if (t != null && !t.active) { bar?.isIndeterminate = false; bar?.progress = 100 }
        if (t == null) { bar?.isIndeterminate = false; bar?.progress = 0 }
        val waiting = t?.status == TStatus.WAITING
        btnYes?.visibility = if (waiting) View.VISIBLE else View.GONE
        btnNo?.visibility = if (waiting) View.VISIBLE else View.GONE
        rowButtons?.visibility = if (t != null && t.active) View.VISIBLE else View.GONE
        bindTime()
        try { wm?.updateViewLayout(card, lp) } catch (e: Exception) { }
    }

    private fun bindTime() {
        val t = TaskManager.tasks.value.firstOrNull { it.active } ?: return
        val sec = ((System.currentTimeMillis() - t.startedAt) / 1000).toInt()
        tvTime?.text = String.format("%d:%02d", sec / 60, sec % 60)
    }
}
